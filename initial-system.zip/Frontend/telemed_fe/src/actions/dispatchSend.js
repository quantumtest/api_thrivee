import { toastr } from 'react-redux-toastr';
import axios from 'axios';

import { send } from '../api/utils';
import { getErrorMsg } from '../helpers/loaders';
import { START_LOAD, END_LOAD, ERROR_LOAD } from '../constants';

const demyFunc = data => data;

const dispatchReceive = (name, data) => dispatch =>
  dispatch({
    type: END_LOAD,
    name,
    data,
  });

const dispatchSend = (
  name,
  sendParams,
  {
    noErrors,
    customError,
    checkBackground,
    adaptData = demyFunc,
    adaptError = demyFunc,
    receiveAction = END_LOAD,
  } = {},
) => dispatch => {
  if (!checkBackground) dispatch({ type: START_LOAD, name });
  return send(sendParams)
    .then(response => {
      if (checkBackground && checkBackground(response)) {
        return response;
      }
      dispatch({
        type: receiveAction,
        name,
        data: adaptData(response.data),
      });
      return response;
    })
    .catch(e => {
      if (!customError && axios.isCancel(e)) {
        return Promise.resolve({ canceledByAxios: true, e });
      }
      if (!noErrors) {
        const msg = getErrorMsg(e);
        if (msg) {
          toastr.error(msg);
        }
      }
      if (!customError) {
        dispatch({
          name,
          type: ERROR_LOAD,
          error: adaptError(e),
        });
      }
      return Promise.reject(e);
    });
};

export { dispatchReceive };

export default dispatchSend;
