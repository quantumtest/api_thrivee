import moment from 'moment';

moment.updateLocale('en', {
  relativeTime: {
    ss: '%ds',
    mm: '%dm',
    hh: '%dh',
    dd: '%dd',
    MM: '%dm',
    yy: '%dy',
  },
});

export default moment;
