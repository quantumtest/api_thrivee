import axios from 'axios';
import { keys, merge, omit, clone, get } from 'lodash';
import axiosCancel from 'axios-cancel';

import push from '../url';

axiosCancel(axios);

function objectToFormData(obj) {
  const data = new window.FormData();
  keys(obj).forEach(key => {
    data.append(key, obj[key]);
  });
  return data;
}

const getDefHeaders = () => ({
  'Content-Type': 'application/json',
  Authorization: `Bearer ${sessionStorage.getItem('token')}`,
  accountId: process.env.BROWSER ? (sessionStorage.getItem('accountId') || 2) : 2, // eslint-disable-line
  'Access-Control-Allow-Origin': '*', // temp
});

const getDefProps = () => ({
  method: 'POST',
  headers: getDefHeaders(),
});

const setId = id => {
  if (process.env.BROWSER) {
    sessionStorage.setItem('accountId', parseInt(id || 1, 10) || 2);
  }
};

const FORM_DATA_HEADERS = {
  'Content-Type': 'multipart/form-data',
};

const checkSendPromise = pr =>
  pr
    .then(res => res || Promise.reject({ message: 'Failed to parse response' }))
    .catch(error => {
      const status = get(error, 'response.status');
      if (status >= 401 && status <= 403) {
        push('login');
      }
      return Promise.reject(error);
    });

function sendFormData(options) {
  return checkSendPromise(
    axios(merge({}, getDefProps(), { headers: FORM_DATA_HEADERS }, options)),
  );
}

function send(options) {
  if (typeof options === 'string') {
    options = { url: options };
  }
  options = clone(options);
  if (typeof options.url === 'function') {
    options.url = options.url();
  }
  if (options.isFormData) {
    return sendFormData(omit(options, ['isFormData']));
  }
  return checkSendPromise(axios(merge({}, getDefProps(), options)));
}

function addBaseUrl(baseURL, method) {
  return options =>
    method({
      ...options,
      url: baseURL + options.url,
    });
}
let baseSend; //eslint-disable-line
if (process.env.BROWSER) {
  baseSend = addBaseUrl(window.App.api.serverUrl, send);
}
export { send, sendFormData, addBaseUrl, objectToFormData, baseSend, setId };
