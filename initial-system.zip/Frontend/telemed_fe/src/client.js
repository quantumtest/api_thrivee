/**
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import 'whatwg-fetch';
import React from 'react';
import ReactDOM from 'react-dom';
import deepForceUpdate from 'react-deep-force-update';
import queryString from 'query-string';
import { createPath } from 'history/PathUtils';
import { forEach, invoke, get } from 'lodash';
import css from 'reflexbox/dist/css';
import { Loader, Dimmer } from 'semantic-ui-react';
import { detect } from './detect-browser';
import App from './components/App';
import createFetch from './createFetch';
import configureStore from './store/configureStore';
import history from './history';
import { updateMeta } from './DOMUtils';
import router from './router';

/* eslint-disable global-require */

// Global (context) variables that can be easily accessed from any React component
// https://facebook.github.io/react/docs/context.html
const context = {
  // Enables critical path CSS rendering
  // https://github.com/kriasoft/isomorphic-style-loader
  insertCss: (...styles) => {
    // eslint-disable-next-line no-underscore-dangle
    const removeCss = styles.map(x => x._insertCss());
    return () => {
      removeCss.forEach(f => f());
    };
  },
  // Universal HTTP client
  fetch: createFetch(self.fetch, {
    baseUrl: window.App.apiUrl,
  }),
  // Initialize a new Redux store
  // http://redux.js.org/docs/basics/UsageWithReact.html
  store: configureStore(window.App.state, { history }),
  storeSubscription: null,
};

// Switch off the native scroll restoration behavior and handle it manually
// https://developers.google.com/web/updates/2015/09/history-api-scroll-restoration
const scrollPositionsHistory = {};
if (window.history && 'scrollRestoration' in window.history) {
  window.history.scrollRestoration = 'manual';
}

let onRenderComplete = function initialRenderComplete() {
  const elem = document.getElementById('css');
  if (elem) elem.parentNode.removeChild(elem);
  onRenderComplete = function renderComplete(route, location) {
    document.title = route.title;

    updateMeta('description', route.description);
    // Update necessary tags in <head> at runtime here, ie:
    // updateMeta('keywords', route.keywords);
    // updateCustomMeta('og:url', route.canonicalUrl);
    // updateCustomMeta('og:image', route.imageUrl);
    // updateLink('canonical', route.canonicalUrl);
    // etc.

    let scrollX = 0;
    let scrollY = 0;
    const pos = scrollPositionsHistory[location.key];
    if (pos) {
      scrollX = pos.scrollX;
      scrollY = pos.scrollY;
    } else {
      const targetHash = location.hash.substr(1);
      if (targetHash) {
        const target = document.getElementById(targetHash);
        if (target) {
          scrollY = window.pageYOffset + target.getBoundingClientRect().top;
        }
      }
    }

    // Restore the scroll position if it was saved into the state
    // or scroll to the given #hash anchor
    // or scroll to top of the page
    window.scrollTo(scrollX, scrollY);

    // Google Analytics tracking. Don't send 'pageview' event after
    // the initial rendering, as it was already sent
    if (window.ga) {
      window.ga('send', 'pageview', createPath(location));
    }
  };
};

const container = document.getElementById('app');
let appInstance;
let currentLocation = history.location;
const browser = detect();

let lastPathname;
// Re-render the app when window.location changes
async function onLocationChange(location, action) {
  // TODO moved check to server
  const urlAllowed = [
    '/login',
    '/forgot-password',
    '/provider',
    '/patient',
    '/register',
    '/email/change',
    '/update-your-browser',
  ];
  let needRedirect = true;
  switch (invoke(browser, 'name.toLowerCase')) {
    case 'chrome':
    case 'crios':
      if (browser.version >= '32.0.1700') needRedirect = false;
      break;
    case 'firefox':
      if (browser.version >= '24.8.0') needRedirect = false;
      break;
    case 'safari':
      if (parseFloat(browser.version) >= parseFloat('6.1.6'))
        needRedirect = false;
      break;
    case 'ios':
      if (browser.version >= '10.0.0') needRedirect = false;
      break;
    case 'edge':
      if (browser.version >= '15') needRedirect = false;
      break;
    default:
      needRedirect = true;
  }
  if (!get(browser, 'name')) needRedirect = false;
  if (needRedirect && window.location.pathname !== '/update-your-browser') {
    history.replace(`/update-your-browser`);
    return;
  }
  if (
    !sessionStorage.getItem('accountId') &&
    !urlAllowed.some(url => location.pathname.indexOf(url) !== -1)
  ) {
    history.replace('/login');
    return;
  } else if (
    sessionStorage.getItem('accountId') &&
    sessionStorage.getItem('fields') &&
    !urlAllowed.some(url => location.pathname.indexOf(url) !== -1)
  ) {
    let step = 0;
    const type = sessionStorage.getItem('type');
    const fields = sessionStorage.getItem('fields');
    const steps = {
      1: ['firstname', 'lastname', 'dateOfBirth', 'ssn'],
      2: ['address'],
      3: ['card', 'insurance'],
    };
    forEach(steps, (value, key) => {
      if (value.some(item => fields.indexOf(item) !== -1)) {
        step = key;
        return false;
      }
    });
    history.replace(`/${type}/${step}`);
    return;
  }

  // Remember the latest scroll position for the previous location
  scrollPositionsHistory[currentLocation.key] = {
    scrollX: window.pageXOffset,
    scrollY: window.pageYOffset,
  };
  // Delete stored scroll position for next page if any
  if (action === 'PUSH') {
    delete scrollPositionsHistory[location.key];
  }
  currentLocation = location;

  try {
    // Traverses the list of routes in the order they are defined until
    // it finds the first route that matches provided URL path string
    // and whose action method returns anything other than `undefined`.

    let innerContainer = document.getElementById('loaderContainer');
    let loaded;
    if (!innerContainer) {
      innerContainer = document.createElement('div');
      innerContainer.setAttribute('id', 'loaderContainer');
      document.body.appendChild(innerContainer);
    }
    innerContainer.setAttribute(
      'style',
      'position: fixed; left: 0; right: 0; top: 0; bottom: 0; z-index: 101',
    );

    setTimeout(() => {
      if (innerContainer && !loaded) {
        ReactDOM.render(
          <Dimmer active inverted>
            <Loader active content="Loading page..." />
          </Dimmer>,
          innerContainer,
        );
      }
    }, 120);
    const route = await router.resolve({
      ...context,
      path: location.pathname,
      query: queryString.parse(location.search),
    });

    loaded = true;
    if (innerContainer) {
      innerContainer.innerHTML = '';
      innerContainer.setAttribute('style', '');
    }
    // Prevent multiple page renders during the routing process
    if (currentLocation.key !== location.key) {
      return;
    }

    if (route.redirect) {
      history.replace(route.redirect);
      return;
    }

    if (lastPathname !== location.pathname) {
      lastPathname = location.pathname;
      css.reset();
    }

    appInstance = ReactDOM.render(
      <App context={context}>{route.component}</App>,
      container,
      () => onRenderComplete(route, location),
    );
  } catch (error) {
    if (__DEV__) {
      throw error;
    }

    console.error(error);

    // Do a full page reload if error occurs during client-side navigation
    if (action && currentLocation.key === location.key) {
      window.location.reload();
    }
  }
}

// Handle client-side navigation by using HTML5 History API
// For more information visit https://github.com/mjackson/history#readme
history.listen(onLocationChange);
onLocationChange(currentLocation);

// Enable Hot Module Replacement (HMR)
if (module.hot) {
  module.hot.accept('./router', () => {
    if (appInstance) {
      // Force-update the whole tree, including components that refuse to update
      deepForceUpdate(appInstance);
    }

    onLocationChange(currentLocation);
  });
}
