if (process.env.BROWSER) {
  throw new Error(
    'Do not import `config.js` from inside the client-side code.',
  );
}

module.exports = {
  version: '0.0.2',

  // Node.js app
  port: process.env.PORT || 3000,
  port2: process.env.PORT2 || 3001,

  // API Gateway
  api: {
    // API URL to be used in the client-side code
    clientUrl:
      process.env.API_CLIENT_URL || 'https://platform.fullcircle.care/',
    // API URL to be used in the server-side code
    serverUrlAdmin:
      process.env.API_SERVER_URL_ADMIN ||
      'https://administrator.fullcircle.care',
    serverUrl: process.env.API_SERVER_URL || 'https://account.fullcircle.care',
    serverUrlDictionary:
      process.env.API_SERVER_URL_DICTIONARY ||
      'https://dictionary.fullcircle.care',
    serverUrlMessage:
      process.env.API_SERVER_URL_MESSAGE || 'https://messenger.fullcircle.care',
    serverUrlNotes:
      process.env.API_SERVER_URL_NOTES || 'https://notes.fullcircle.care',
    serverUrlNPI:
      process.env.API_SERVER_URL_NPI || 'https://npi.fullcircle.care',
    serverUrlEligibility:
      process.env.API_SERVER_URL_ELIGIBILITY ||
      'https://pokitdok.fullcircle.care',
    serverUrlSchedule:
      process.env.API_SERVER_URL_SCHEDULE || 'https://schedule.fullcircle.care',
    serverUrlBilling:
      process.env.API_SERVER_URL_BILLING || 'https://stripe.fullcircle.care',
    serverUrlZoom:
      process.env.API_SERVER_URL_ZOOM || 'https://zoom.fullcircle.care',
  },

  // Web analytics
  analytics: {
    // https://analytics.google.com/
    googleTrackingId: process.env.GOOGLE_TRACKING_ID, // UA-XXXXX-X
  },
};
