import React, { Component } from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import { pick } from 'lodash';
import NoSSR from '../../components/NoSSR';

import main from '../../theme/main.glob.scss';
import semantic from '../../theme/form.glob.scss';

@withStyles(main, semantic)
class ForgotPassword extends Component {
  render() {
    return (
      <NoSSR
        element={() =>
          React.createElement(
            require('./components/index').default,
            pick(this.props, ['hash']),
          )}
      />
    );
  }
}

export default ForgotPassword;
