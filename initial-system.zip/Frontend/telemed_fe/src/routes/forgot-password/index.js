import React from 'react';
import ForgotPassword from './ForgotPassword';

const title = 'Forgot password';

function action({ params }) {
  return {
    chunks: ['forgot-password'],
    title,
    component: <ForgotPassword title={title} {...params} />,
  };
}

export default action;
