import React from 'react';
import { pick } from 'lodash';
import Layout from '../../components/Layout';
import { setId } from '../../api/utils';
import NoSSR from '../../components/NoSSR';

function action({ params }) {
  if (params.accountId) {
    setId(params.accountId);
  }

  return {
    chunks: ['patient'],
    title: 'Patient - Diagnostic Impressions',
    component: (
      <Layout childrenContainerOnly>
        <NoSSR
          element={() =>
            React.createElement(
              require('./components/index').default,
              pick(params, ['patientId']),
            )
          }
        />
      </Layout>
    ),
  };
}

export default action;
