import React, { Component } from 'react';
import NoSSR from '../../components/NoSSR';

class MyPatients extends Component {
  render() {
    return (
      <NoSSR
        element={() =>
          React.createElement(require('./components/index').default)}
      />
    );
  }
}

export default MyPatients;
