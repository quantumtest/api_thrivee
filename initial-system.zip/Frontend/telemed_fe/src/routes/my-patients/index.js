import React from 'react';

import Layout from '../../components/Layout';
import HeaderComponent from '../../components/Header';
import MyPatients from './MyPatients';

const title = 'My Patients';

function action() {
  return {
    chunks: ['my-patients'],
    title,
    component: (
      <Layout childrenContainerOnly>
        <HeaderComponent
          title={title}
          btn="Register Established Patient"
          type="Patient"
        />
        <MyPatients title={title} />
      </Layout>
    ),
  };
}

export default action;
