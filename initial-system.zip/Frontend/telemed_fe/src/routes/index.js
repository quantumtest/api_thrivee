/* eslint-disable global-require */

// The top-level (parent) route
// import moment from 'moment';
import eligibility from './eligibilityRoute';

const routes = [
  {
    path: '/login',
    name: 'login',
    load: () => import(/* webpackChunkName: 'login' */ './login'),
  },
  {
    path: '/update-your-browser',
    name: 'updatebrowser',
    load: () => import(/* webpackChunkName: 'login' */ './update-your-browser'),
  },
  {
    path: '/email/change/:hash',
    name: 'emailChange',
    load: () => import(/* webpackChunkName: 'login' */ './login'),
  },
  {
    path: '/register',
    children: [
      {
        path: '/patient',
        children: [
          {
            name: 'register.patient.newuser',
            path: '/newuser',
            load: () => import(/* webpackChunkName: 'register' */ './register'),
          },
          {
            name: 'register.patient.invited',
            path: '/invited/:hash',
            load: () => import(/* webpackChunkName: 'register' */ './register'),
          },
          {
            name: 'register.patient.activation',
            path: '/activation/:hash',
            load: () => import(/* webpackChunkName: 'login' */ './login'),
          },
        ],
      },
      {
        path: '/provider',
        children: [
          {
            name: 'register.provider.newuser',
            path: '/newuser',
            load: () => import(/* webpackChunkName: 'register' */ './register'),
          },
          {
            name: 'register.provider.invited',
            path: '/invited/:hash',
            load: () => import(/* webpackChunkName: 'register' */ './register'),
          },
          {
            name: 'register.provider.activation',
            path: '/activation/:hash',
            load: () => import(/* webpackChunkName: 'login' */ './login'),
          },
        ],
      },
    ],
  },
  {
    path: '/provider/:step',
    name: 'provider.step',
    load: () => import(/* webpackChunkName: 'steps' */ './steps'),
  },
  {
    path: '/patient/:step',
    name: 'patient.step',
    load: () => import(/* webpackChunkName: 'steps' */ './steps'),
  },
  {
    path: '/forgot-password',
    children: [
      {
        path: '/',
        name: 'forgot-password',
        load: () =>
          import(/* webpackChunkName: 'password' */ './forgot-password'),
      },
      {
        path: '/:hash',
        name: 'forgot-password.confirm',
        load: () =>
          import(/* webpackChunkName: 'password' */ './forgot-password'),
      },
    ],
  },
  {
    path: '/',
    // Keep in mind, routes are evaluated in order
    children: [
      {
        path: '/',
        name: 'home',
        load: () => import(/* webpackChunkName: 'home' */ './home'),
      },
      {
        path: '/contact',
        load: () => import(/* webpackChunkName: 'contact' */ './contact'),
      },
      {
        path: '/about',
        load: () => import(/* webpackChunkName: 'about' */ './about'),
      },
      {
        path: '/privacy',
        name: 'privacy',
        load: () => import(/* webpackChunkName: 'privacy' */ './privacy'),
      },
      {
        path: '/profile',
        name: 'profile',
        children: [
          {
            name: 'profile.personal-info',
            path: '',
            load: () => import(/* webpackChunkName: 'profile' */ './profile'),
          },
          {
            name: 'profile.professional-info',
            path: '/professional-info',
            load: () => import(/* webpackChunkName: 'profile' */ './profile'),
          },
          {
            name: 'profile.profile-settings',
            path: '/profile-settings',
            load: () => import(/* webpackChunkName: 'profile' */ './profile'),
          },
          {
            name: 'profile.profile-insurance',
            path: '/profile-insurance',
            load: () => import(/* webpackChunkName: 'profile' */ './profile'),
          },
        ],
      },
      // {
      //   path: '/schedule',
      //   name: 'schedule',
      //   load: () => import(/* webpackChunkName: 'schedule' */ './schedule'),
      // },
      {
        path: '/admin',
        children: [
          {
            name: 'admin',
            path: '/',
            load: () => import(/* webpackChunkName: 'admin' */ './admin'),
          },
          {
            name: 'admin.providers',
            path: '/providers',
            load: () => import(/* webpackChunkName: 'admin' */ './admin'),
          },
          {
            name: 'admin.patients',
            path: '/patients',
            load: () => import(/* webpackChunkName: 'admin' */ './admin'),
          },
          {
            name: 'admin.config',
            path: '/config',
            load: () =>
              import(/* webpackChunkName: 'config' */ './admin-config'),
          },
          {
            path: '/statistic',
            children: [
              {
                name: 'admin.statistic',
                path: '/',
                load: () =>
                  import(/* webpackChunkName: 'statistic' */ './statistic'),
              },
              {
                name: 'admin.statistic.view',
                path: '/:type/:accountId',
                load: () =>
                  import(/* webpackChunkName: 'statistic' */ './statistic/statistic-view'),
              },
            ],
          },
        ],
      },
      {
        path: '/account',
        name: 'account',
        load: () => import(/* webpackChunkName: 'account' */ './account'),
      },
      {
        path: '/billing-info',
        name: 'billing-info',
        load: () => import(/* webpackChunkName: 'account' */ './billing-info'),
      },
      {
        path: '/documents',
        name: 'documents',
        load: () => import(/* webpackChunkName: 'account' */ './documents'),
      },
      {
        path: '/practice',
        name: 'practice',
        load: () => import(/* webpackChunkName: 'practice' */ './practice'),
      },
      {
        path: '/message',
        name: 'message',
        children: [
          {
            name: 'message.preview',
            path: '',
            load: () => import(/* webpackChunkName: 'message' */ './message'),
          },
          {
            name: 'message.view',
            path: '/:notMeId/:notMeType',
            load: () => import(/* webpackChunkName: 'message' */ './message'),
          },
        ],
      },
      {
        path: '/schedule',
        name: 'schedule',
        load: () => import(/* webpackChunkName: 'schedule' */ './schedule'),
      },
      {
        path: '/my-patients',
        name: 'my-patients',
        children: [
          {
            name: 'my-patients.list',
            path: '',
            load: () =>
              import(/* webpackChunkName: 'patient' */ './my-patients'),
          },
          {
            name: 'my-patients.view',
            path: '/:patientId',
            load: () => import(/* webpackChunkName: 'patient' */ './patient'),
          },
          {
            name: 'my-patients.diagnostic-impressions',
            path: '/:patientId/diagnostic-impressions',
            load: () =>
              import(/* webpackChunkName: 'patient' */ './diagnostic-impressions'),
          },
          {
            name: 'my-patients.notes',
            path: '/:patientId/notes',
            load: () => import(/* webpackChunkName: 'patient' */ './notes'),
          },
          {
            name: 'my-patients.conference-history',
            path: '/:patientId/conference-history',
            load: () =>
              import(/* webpackChunkName: 'patient' */ './conference-history'),
          },
          eligibility,
        ],
      },
      {
        path: '/providerProfile/:providerId',
        name: 'provider.view',
        title: 'Provider',
        load: () =>
          import(/* webpackChunkName: 'providerview' */ './provider-view'),
      },
      {
        path: '/providerProfile/:providerId/conference-history',
        name: 'my-provider.conference-history',
        load: () =>
          import(/* webpackChunkName: 'providerview' */ './conference-history-provider'),
      },
      {
        path: '/my-network',
        name: 'my-network',
        title: 'My Network',
        load: () => import(/* webpackChunkName: 'network' */ './my-network'),
      },
      {
        path: '/my-network/for-patient/:patientId',
        name: 'my-network.patient',
        title: 'My Network',
        load: () => import(/* webpackChunkName: 'network' */ './my-network'),
      },
      {
        path: '/my-providers',
        name: 'my-providers',
        load: () => import(/* webpackChunkName: 'provider' */ './my-providers'),
      },
      {
        path: '/conference-history',
        name: 'conference-history',
        load: () => import(/* webpackChunkName: 'profile' */ './billing'),
      },

      // Wildcard routes, e.g. { path: '*', ... } (must go last)
      {
        path: '*',
        load: () => import(/* webpackChunkName: 'not-found' */ './not-found'),
      },
    ],
    async action({ next }) {
      // Execute each child route until one of them return the result
      const route = await next();

      // Provide default values for title, description etc.
      route.title = `${route.title || 'Untitled Page'} - FullCircle`;
      route.description = route.description || '';

      return route;
    },
  },
];

// The error page is available by permanent url for development mode
if (__DEV__) {
  routes[6].children.unshift({
    path: '/error',
    action: require('./error').default,
  });
}

export default routes;
