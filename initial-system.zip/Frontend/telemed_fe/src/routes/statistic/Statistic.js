import React from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import {
  getMetrics,
  getSystemMoney,
  getCommunication,
  getReferral,
  getMessage,
  getTransactions,
} from '../../actions/admin';
import HeaderComponent from '../../components/Header';
import Grafic from './components/GraficComponent';
import s from './Statistic.scss';

class Statistic extends React.Component {
  render() {
    return (
      <div>
        <HeaderComponent title="Main Statistics" />
        <div className={s.container}>
          <Grafic
            title="Payment statistics:"
            action={getSystemMoney}
            money
            runtimeReducer="systemMoney"
            timeDataList="metricsByAmountDtoList"
            arrays={[
              {
                from: 'metricsByAmountDtoList',
                title: 'Amount $',
              },
              {
                from: 'metricsByFeeDtoList',
                title: 'Fee $',
              },
            ]}
          />
          <Grafic
            title="Transactions statistics:"
            action={getTransactions}
            runtimeReducer="transactions"
            timeDataList="metricsSuccessTransactions"
            arrays={[
              {
                from: 'metricsSuccessTransactions',
                title: 'Success',
              },
              {
                from: 'metricsFailedTransactions',
                title: 'Failed',
              },
            ]}
          />
          <Grafic
            title="Registration statistics:"
            action={getMetrics}
            runtimeReducer="metrics"
            timeDataList="metricsPatientDtoList"
            arrays={[
              {
                from: 'metricsPatientDtoList',
                title: 'Patients',
              },
              {
                from: 'metricsProviderDtoList',
                title: 'Providers',
              },
            ]}
          />
          <Grafic
            title="Communication statistics:"
            action={getCommunication}
            runtimeReducer="communication"
            timeDataList="metricsMessageDtoList"
            arrays={[
              {
                from: 'metricsMessageDtoList',
                title: 'Message',
              },
              {
                from: 'metricsTeleconferenceDtoList',
                title: 'Teleconference',
              },
            ]}
          />
          <Grafic
            title="Referrals: statistics:"
            action={getReferral}
            runtimeReducer="referral"
            timeDataList="dataArray"
            arrays={[
              {
                from: 'dataArray',
                title: 'Referrals',
              },
            ]}
          />
          <Grafic
            title="Messages statistics:"
            action={getMessage}
            runtimeReducer="message"
            timeDataList="dataArray"
            arrays={[
              {
                from: 'dataArray',
                title: 'Messangers',
              },
            ]}
          />
        </div>
      </div>
    );
  }
}

export default withStyles(s)(Statistic);
