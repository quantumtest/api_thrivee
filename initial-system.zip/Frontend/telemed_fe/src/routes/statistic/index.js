import React from 'react';
import Layout from '../../components/Layout';
import NoSSR from '../../components/NoSSR';

const title = 'Admin Page';

function action({ path }) {
  return {
    chunks: ['admin'],
    title,
    component: (
      <Layout admin childrenContainerOnly>
        <NoSSR
          element={() =>
            React.createElement(require('./Statistic').default, {
              path,
              title,
            })}
        />
      </Layout>
    ),
  };
}

export default action;
