import React from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import HeaderComponent from '../../components/Header';
import List from './components/List';
import Search from './components/Search';
import s from './Admin.scss';
import { search } from '../../actions/admin';

class Admin extends React.Component {
  get options() {
    if (this.props.path === '/patients') {
      return {
        action: search,
        type: 'patients',
      };
    }
    return {
      action: search,
      type: 'providers',
    };
  }

  get adminHeader() {
    switch (this.props.path) {
      case '/providers':
        return 'Providers list';
      case '/patients':
        return 'Patients list';
      default:
        return 'Providers list';
    }
  }

  render() {
    return (
      <div>
        <HeaderComponent title={this.adminHeader} />
        <div className={s.container}>
          <Search type={this.options.type} />
          <List {...this.options} />
        </div>
      </div>
    );
  }
}

export default withStyles(s)(Admin);
