import React from 'react';
import NoSSR from '../../components/NoSSR';
import Layout from '../../components/Layout';
import HeaderComponent from '../../components/Header';

const title = 'Conference History';

function action() {
  return {
    chunks: ['my-patients'],
    title,
    component: (
      <Layout childrenContainerOnly>
        <HeaderComponent title={title} />
        <NoSSR
          element={() =>
            React.createElement(require('./components/index').default)}
        />
      </Layout>
    ),
  };
}

export default action;
