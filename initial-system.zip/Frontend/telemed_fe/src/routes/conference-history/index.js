import React from 'react';
import Layout from '../../components/Layout';
import ConferenceHistory from './ConferenceHistory';
import ActionLoader from '../../components/ActionLoader';
import { getPatient } from '../../actions/user';

function action({ params, url: path }) {
  const getPatientL = () => getPatient(params.patientId);
  return {
    chunks: ['patient'],
    title: 'Patient - Conference History',
    component: (
      <Layout childrenContainerOnly>
        <ActionLoader
          notCheckLen
          relative
          paddedWrapper
          checkAction
          name="patientProfile"
          action={getPatientL}
        >
          <ConferenceHistory {...params} path={path} />
        </ActionLoader>
      </Layout>
    ),
  };
}

export default action;
