import React, { Component } from 'react';
import { pick } from 'lodash';

import NoSSR from '../../components/NoSSR';

class ConferenceHistory extends Component {
  render() {
    return (
      <NoSSR
        element={() =>
          React.createElement(
            require('./components/index').default,
            pick(this.props, ['patientId', 'providerId', 'path']),
          )}
      />
    );
  }
}

export default ConferenceHistory;
