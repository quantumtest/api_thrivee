import React from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';

import s from './style.scss';

class Statistic extends React.Component {
  render() {
    return (
      <div className={s.wrapper}>
        <div className={s.block}>
          <img src="/assets/images/fulllogo.svg" className={s.fullLogo} />
          <h4>We don't support this browser</h4>
          <a href="https://www.google.com/chrome/">
            <h6>We recommend download last version Chrome</h6>
          </a>
        </div>
      </div>
    );
  }
}

export default withStyles(s)(Statistic);
