import React from 'react';
import NoSSR from '../../components/NoSSR';
import Page from './Update';

function action() {
  return {
    chunks: ['update'],
    title: 'Update your browser',
    component: <NoSSR element={() => <Page />} />,
  };
}

export default action;
