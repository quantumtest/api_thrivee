/* eslint-disable class-methods-use-this */
import React, { Component } from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import NoSSR from '../../components/NoSSR';
import { pick } from 'lodash';

import a from './Account.scss';
import semantic from '../../theme/form.glob.scss';

@withStyles(semantic, a)
class Account extends Component {
  render() {
    return (
      <NoSSR
        element={() =>
          React.createElement(
            require('./components/index').default,
            pick(this.props, ['hash', 'type']),
          )}
      />
    );
  }
}

export default Account;
