import React from 'react';
import Layout from '../../components/Layout';
import Account from './Account';

import HeaderComponent from '../../components/Header';
import { SETTINGS_PROVIDER, ADMIN_TYPE, SETTINGS_ADMIN } from '../../constants';

const title = 'Account';

export default function({ params }) {
  let type = null;
  if (process.env.BROWSER) {
    type = sessionStorage.getItem('type');
  }

  return {
    chunks: ['account'],
    title,
    component: (
      <Layout childrenContainerOnly>
        {<HeaderComponent title="Settings" body={type === ADMIN_TYPE ? SETTINGS_ADMIN : SETTINGS_PROVIDER} />}
        <Account title={title} {...params} type={type}/>
      </Layout>
    ),
  };
}

