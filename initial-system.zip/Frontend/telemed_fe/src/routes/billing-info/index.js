import React from 'react';
import Layout from '../../components/Layout';
import NoSSR from '../../components/NoSSR';

import HeaderComponent from '../../components/Header';
import { SETTINGS_PROVIDER } from '../../constants';

const title = 'Billing info';

export default function() {
  return {
    chunks: ['account'],
    title,
    component: (
      <Layout childrenContainerOnly>
        <HeaderComponent title="Settings" body={SETTINGS_PROVIDER} />
        <NoSSR
          element={() => React.createElement(require('./BillingInfo').default)}
        />
      </Layout>
    ),
  };
}
