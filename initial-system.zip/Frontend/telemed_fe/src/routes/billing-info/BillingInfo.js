import React, { Component } from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import Cash from '../../components/images/Cash';

import Card from './components/Card';
import Container from '../../components/SettingImportantContainer';
import ActionLoader from '../../components/ActionLoader';
import { getCard } from '../../actions/user';

import a from './BillingInfo.scss';

@withStyles(a)
class BillingInfo extends Component {
  render() {
    return (
      <Container
        texts={[
          'In order to host sessions on our site, please add a personal or business ' +
            'credit card against which we will charge session fees (if they apply) and ' +
            'only if there is a balance due to us. If we are able to deduct fees from funds ' +
            'due to you from appointment charges, we will not use your credit card.',
          'Please enter a credit, debit, FSA, or HSA card to \n' +
            'automatically pay after your appointment. \n' +
            'We never charge your card until after your \n' +
            'appointment. You can read more about our payment \n' +
            'policies. \n',
        ]}
        icon={<Cash />}
        title="Billing Fee"
      >
        <ActionLoader name="card" action={getCard} notCheckLen clearOnUnmount>
          <Card />
        </ActionLoader>
      </Container>
    );
  }
}

export default BillingInfo;
