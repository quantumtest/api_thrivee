import React from 'react';

import Layout from '../../components/Layout';
import HeaderComponent from '../../components/Header';
import MyProviders from './MyProviders';

const title = 'My providers';

function action() {
  return {
    chunks: ['my-providers'],
    title,
    component: (
      <Layout childrenContainerOnly>
        <HeaderComponent title={title} />
        <MyProviders title={title} />
      </Layout>
    ),
  };
}

export default action;
