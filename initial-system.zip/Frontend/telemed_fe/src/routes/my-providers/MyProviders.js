import React, { Component } from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import NoSSR from '../../components/NoSSR';

import semanticS from './styles.glob.scss';

@withStyles(semanticS)
class MyProviders extends Component {
  render() {
    return (
      <NoSSR
        element={() =>
          React.createElement(require('./components/index').default)}
      />
    );
  }
}

export default MyProviders;
