import React from 'react';
import { pick } from 'lodash';

import Layout from '../../components/Layout';
import NoSSR from '../../components/NoSSR';

const title = 'Message';

function action({ params, query }) {
  return {
    chunks: ['message'],
    title,
    component: (
      <Layout noContainer>
        <NoSSR
          element={() =>
            React.createElement(require('./Message').default, {
              title,
              query,
              options: pick(params, ['notMeId', 'notMeType']),
            })}
        />
      </Layout>
    ),
  };
}

export default action;
