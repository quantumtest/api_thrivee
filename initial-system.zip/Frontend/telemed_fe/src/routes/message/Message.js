import React, { Component } from 'react';
import { Grid, Header, Loader } from 'semantic-ui-react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import cn from 'classnames';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { pick, get } from 'lodash';
import { Flex } from 'reflexbox';

import MessageUserDetails from './components/MessageUserDetails/MessegeUserDetails';
import CreateMessageComponent from './components/CreateMessage/CreateMessageComponent';
import Messages from './components/Message/MessageComponent';
import Filter from './components/Filter/FilterComponent';
import MobileHeader from './components/MobileHeader';
import { SYS_USER } from '../../constants';
import UserRightBar from './components/UserItem/UserItemComponent';
import SearchResults from './components/SearchResults';

import a from './Message.scss';

import { getMyAccount } from '../../actions/user';

const mapStateToProps = ({ runtime, layout }) => ({
  ...pick(runtime, ['myProfileLoaded', 'myProfileError', 'myProfileData']),
  messengerId: runtime.messengersData,
  errorMessages: runtime.messengersError || runtime.messagesError,
  hasSearch:
    runtime.messengersSearchLoading ||
    runtime.messengersSearchData ||
    runtime.messengersSearchError,
  isNorm: layout.isNorm,
  isTab: layout.isTab,
  isMob: layout.isMob,
});

const mapDispatchToProps = dispatch =>
  bindActionCreators({ getMyAccount, dispatch }, dispatch);

@withStyles(a)
@connect(mapStateToProps, mapDispatchToProps)
export default class Message extends Component {
  static propTypes = {
    options: PropTypes.object,
    myProfileLoaded: PropTypes.bool,
    myProfileError: PropTypes.bool,
    myProfileData: PropTypes.object,
    messengerId: PropTypes.number,
    query: PropTypes.object,
    errorMessages: PropTypes.object,
    getMyAccount: PropTypes.func.isRequired,
  };

  componentDidMount() {
    this.props.getMyAccount();
  }

  componentWillUnmount() {
    this.props.dispatch({
      type: 'RESET_RUNTIME',
      names: ['messengers', 'messages'],
    });
  }

  get notMeId() {
    return parseInt(get(this.props.options, 'notMeId'), 10);
  }

  getMessages = (notMeId, options) => {
    const props = this.props;
    if (props.errorMessages) {
      return <Header as="h1">Loading Error</Header>;
    }
    if (!notMeId) {
      return;
    }
    return [
      <Flex
        column
        w={[1, 2 / 3, 2 / 3, 1 / 2]}
        className={a.secondColumn}
        key="2"
      >
        {props.isNorm && <MobileHeader {...options} />}
        <Messages {...options} hasHeader={props.isNorm} />
        {props.messengerId && <CreateMessageComponent {...options} />}
      </Flex>,
      !props.isNorm &&
      options.notMeId !== SYS_USER && (
        <Flex column w={1 / 4} className={a.whiteWr} key="3">
          <MessageUserDetails {...options} />
        </Flex>
      ),
    ];
  };

  render() {
    const props = this.props;
    if (!props.myProfileLoaded) {
      return <Loader active content="Loading..." />;
    }
    if (props.myProfileError || !props.myProfileData) {
      return (
        <Grid>
          <Header as="h1">My Profile Error</Header>
        </Grid>
      );
    }
    const notMeId = this.notMeId;
    const options = { ...props.query, ...props.options, notMeId };
    return (
      <Flex
        className={cn([
          a.messagePageWr,
          { 'messenger-istablet': props.isNorm },
        ])}
      >
        {!(props.isMob && notMeId) && (
          <Flex column w={[1, 1 / 3, 1 / 3, 1 / 4]} className={a.whiteWr}>
            <Filter {...options} />
            {props.hasSearch ? (
              <SearchResults {...options} />
            ) : (
              <UserRightBar {...options} />
            )}
          </Flex>
        )}
        {this.getMessages(notMeId, options)}
      </Flex>
    );
  }
}
