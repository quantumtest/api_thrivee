/* eslint-disable import/extensions */
import React, { Component } from 'react';
import { pick } from 'lodash';
import PropTypes from 'prop-types';

import NoSSR from '../../components/NoSSR';

class Patient extends Component {
  static propTypes = {
    patientId: PropTypes.string,//eslint-disable-line
  };

  render() {
    return (
      <NoSSR
        element={() =>
          React.createElement(
            require('./components/index').default,
            pick(this.props, ['patientId']),
          )}
      />
    );
  }
}

export default Patient;
