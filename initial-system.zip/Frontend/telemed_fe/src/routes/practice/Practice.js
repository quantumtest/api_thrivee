import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Container } from 'semantic-ui-react';

import PracticeInfoComponent from './components/PracticeInfoComponent';

const mapStateToProps = () => ({});

@connect(mapStateToProps)
class Practice extends Component {
  render() {
    return (
      <div>
        <Container text>
          <PracticeInfoComponent />
        </Container>
      </div>
    );
  }
}

export default Practice;
