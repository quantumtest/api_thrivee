import React from 'react';
import Layout from '../../components/Layout';
import Practice from './Practice';

import HeaderComponent from '../../components/Header';
import { SETTINGS_PROVIDER } from '../../constants';

const title = 'Practice';

function action() {
  return {
    chunks: ['practice'],
    title,
    component: (
      <Layout childrenContainerOnly>
        <HeaderComponent title="Settings" body={SETTINGS_PROVIDER} />
        <Practice title={title} />
      </Layout>
    ),
  };
}

export default action;
