/* eslint-disable import/extensions */
import React, { Component } from 'react';
import { connect } from 'react-redux';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import { pick } from 'lodash';
import NoSSR from '../../components/NoSSR';

import semantic from '../../theme/form.glob.scss';

const mapStateToProps = () => ({});

@withStyles(semantic)
@connect(mapStateToProps)
class Profile extends Component {
  render() {
    return (
      <NoSSR
        element={() =>
          React.createElement(
            require('./components/index').default,
            pick(this.props, [
              'profile',
              'profileLoaded',
              'profileLoading',
              'path',
            ]),
          )}
      />
    );
  }
}

export default Profile;
