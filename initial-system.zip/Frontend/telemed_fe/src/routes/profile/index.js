import React from 'react';
import Layout from '../../components/Layout';
import Profile from './Profile';

import HeaderComponent from '../../components/Header';
import { SETTINGS_PROVIDER } from '../../constants';

const title = 'Profile';

export default function action({ path }) {
  return {
    chunks: ['profile'],
    title,
    // TODO move noContainer for all layout
    component: (
      <Layout childrenContainerOnly>
        <HeaderComponent title="Settings" body={SETTINGS_PROVIDER} />
        <Profile title={title} path={path} />
      </Layout>
    ),
  };
}
