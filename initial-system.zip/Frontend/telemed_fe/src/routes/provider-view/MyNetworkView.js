import React, { Component } from 'react';
import { pick } from 'lodash';
import PropTypes from 'prop-types';
import ActionLoader from '../../components/ActionLoader';

import { getProviderForNetwork } from '../../actions/user/provider';
import NoSSR from '../../components/NoSSR';

class Patient extends Component {
  static propTypes = {
    providerId: PropTypes.string,//eslint-disable-line
  };

  render() {
    return (
      <ActionLoader
        name="providerProfile"
        clearOnUnmount
        action={() => getProviderForNetwork(this.props.providerId)}
        notCheckLen
      >
        <NoSSR
          element={() =>
            React.createElement(
              require('./components/index').default,
              pick(this.props, ['providerId']),
            )}
        />
      </ActionLoader>
    );
  }
}

export default Patient;
