import React from 'react';

import Layout from '../../components/Layout';
import NoSSR from '../../components/NoSSR';
import HeaderComponent from '../../components/Header';

const title = 'My network';

function action({ params }) {
  return {
    chunks: ['my-network'],
    title,
    component: (
      <Layout childrenContainerOnly>
        <HeaderComponent title={title} btn="Invite Provider" type="Provider" />
        <NoSSR
          element={() =>
            React.createElement(
              require('./components/Container').default,
              params,
            )}
        />
      </Layout>
    ),
  };
}

export default action;
