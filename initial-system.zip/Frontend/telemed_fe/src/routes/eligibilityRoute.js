const load = () => import(/* webpackChunkName: 'patient' */ './eligibility');
const eligibility = {
  name: 'my-patients.eligibility',
  path: '/:patientId/eligibility',
  children: [
    {
      name: 'my-patients.eligibility.withProvider',
      path: '/:providerId',
      children: [
        {
          path: '/',
          load,
        },
        {
          name: 'my-patients.eligibility.coverageWithProvider',
          path: '/coverage',
          load,
        },
        {
          name: 'my-patients.eligibility.out-of-pocketWithProvider',
          path: '/out-of-pocket',
          load,
        },
        {
          name: 'my-patients.eligibility.coinsuranceWithProvider',
          path: '/coinsurance',
          load,
        },
        {
          name: 'my-patients.eligibility.copayWithProvider',
          path: '/copay',
          load,
        },
      ],
    },
    {
      path: '/',
      load,
    },
    {
      name: 'my-patients.eligibility.coverage',
      path: '/coverage',
      load,
    },
    {
      name: 'my-patients.eligibility.out-of-pocket',
      path: '/out-of-pocket',
      load,
    },
    {
      name: 'my-patients.eligibility.coinsurance',
      path: '/coinsurance',
      load,
    },
    {
      name: 'my-patients.eligibility.copay',
      path: '/copay',
      load,
    },
  ],
};
export default eligibility;
