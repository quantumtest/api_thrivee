import React from 'react';
import Login from './Login';

const title = 'Log In';

function action({ route, params }) {
  return {
    chunks: ['login'],
    title,
    component: (
      <Login
        title={title}
        {...params}
        route={route.name}
        parent={route.parent.path}
      />
    ),
  };
}

export default action;
