import React from 'react';
import { reduxForm } from 'redux-form';
import PropTypes from 'prop-types';
import { toastr } from 'react-redux-toastr';
import { Form, Button, Message } from 'semantic-ui-react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { cloneDeep, forEach, get } from 'lodash';
import withStyles from 'isomorphic-style-loader/lib/withStyles';

import push, { url } from '../../url';
import { getMyAccount } from '../../actions/user';
import { login, register, resendConfirmationLink } from '../../actions/auth';
import { setRuntimeVariable } from '../../actions/runtime';
import { required, email } from '../../helpers/validations';
import { toastrError, sendLoadingPromise } from '../../helpers/loaders';

import Field from '../../components/forms/reduxField';
import Password from '../../components/forms/Password';
import Link from '../../components/Link';
import OnBoardingBlock from '../../components/OnBoarding/OnBoardingBlock';

import main from '../../theme/main.glob.scss';
import form from '../../theme/form.glob.scss';
import s from './Login.scss';
import {
  PATIENT_TYPE,
  PROVIDER_TYPE,
  SERVER_PROVIDER_TYPE,
  ADMIN_TYPE,
  SERVER_ADMIN_TYPE,
} from '../../constants';

const steps = {
  1: ['firstName', 'lastName', 'dateOfBirth', 'ssn'],
  2: ['address'],
  3: ['card', 'insurance'],
};

const mapStateToProps = state => ({
  sendusername: get(state.form, 'LoginForm.values.username'),
  sticker: state.runtime.loginStickerData,
});

const mapDispatchToProps = dispatch =>
  bindActionCreators({ dispatch, getMyAccount, setRuntimeVariable }, dispatch);

@connect(mapStateToProps, mapDispatchToProps)
@withStyles(s, form, main)
@reduxForm({
  form: 'LoginForm',
})
class Login extends React.Component {
  static propTypes = {
    handleSubmit: PropTypes.func.isRequired,
    getMyAccount: PropTypes.func.isRequired,
    valid: PropTypes.bool,
  };

  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      showResetButton: false,
    };
  }

  componentDidMount() {
    const { route, parent, hash } = this.props;
    let path;
    let successMsg;
    if (hash) {
      if (parent !== '/') {
        path = `${parent}/email/confirm`;
        successMsg = 'Your email is confirmed!';
      } else if (route === 'emailChange') {
        path = '/changeEmail/confirm';
        successMsg = 'Your email is change! Please, log in with new email.';
      }
      sendLoadingPromise(
        loading => this.setState({ loading }),
        (async () => {
          try {
            await register(path, {
              url: encodeURIComponent(hash),
            });
            toastr.success(successMsg);
          } catch (e) {
            toastrError(e);
            const expMessage =
              get(e, 'response.data.message') || get(e, 'message') || '';
            if (expMessage.toLowerCase().includes('link expired')) {
              this.setState({ showResetButton: true });
            }
          }
        })(),
      );
    }
  }

  onSubmit = async data => {
    if (!this.props.valid) {
      return;
    }
    this.setState({ loading: true });
    data = cloneDeep(data);
    try {
      data.username = data.username.trim();
      data.password = btoa(data.password);
      const resp = await login(data);
      const accountResp = await this.props.getMyAccount();
      const fields = resp.data.emptyMandatoryField;
      let type = PATIENT_TYPE;
      accountResp.data.roles.some(role => {
        if (role.accountType === SERVER_PROVIDER_TYPE) {
          type = PROVIDER_TYPE;
          return true;
        }
        if (role.accountType === SERVER_ADMIN_TYPE) {
          type = ADMIN_TYPE;
          return true;
        }
        return false;
      });
      sessionStorage.setItem('type', type);
      this.props.setRuntimeVariable({
        name: 'loginStickerData',
        value: '',
      });
      if (fields !== null) {
        sessionStorage.setItem('fields', fields);
        let step = 0;
        forEach(steps, (value, key) => {
          if (value.some(item => fields.indexOf(item) !== -1)) {
            step = key;
            return false;
          }
        });
        push(`${type}.step`, { step });
      } else {
        sessionStorage.removeItem('fields');
        if (type !== ADMIN_TYPE) push('home');
        else push(ADMIN_TYPE);
      }
    } catch (e) {
      console.info(e);
      this.setState({ loading: false });
      toastrError(e);
    }
  };

  resetLink = () => {
    let { parent } = this.props;
    parent = parent.substring(1);
    const useremail = this.props.sendusername;
    if (useremail && parent) {
      sendLoadingPromise(
        loading => this.setState({ loading }),
        (async () => {
          await resendConfirmationLink(parent, {
            email: useremail,
          });
          this.setState({ showResetButton: false });
        })(),
      );
    } else {
      toastr.error(
        'Your confirmation link has expired. Please enter your email address to the field below and click ‘Resend Link’ button.',
      );
    }
  };

  render() {
    return (
      <OnBoardingBlock title="Enter Full Circle">
        {this.state.showResetButton && (
          <Message warning className={s.resendLinkContainer}>
            Your link is expired &nbsp;<a href="#" onClick={this.resetLink}>
              Resend link
            </a>&nbsp;.
          </Message>
        )}
        {this.props.sticker && (
          <Message success className={s.successLinkContainer}>
            {this.props.sticker}
          </Message>
        )}
        <Form
          loading={this.state.loading}
          onSubmit={this.props.handleSubmit(this.onSubmit)}
        >
          <Field
            label="Email address"
            name="username"
            placeholder="Email"
            validate={[required, email]}
          />
          <Field
            label={
              <span>
                Password
                <Link to={url('forgot-password')} aClassName={s.forgotPassword}>
                  Forgot password?
                </Link>
              </span>
            }
            name="password"
            placeholder="Password"
            component={Password}
            validate={required}
          />
          <Button className={s.buttonSubmit} content="Sign in" />
          <div className={s.btnsGroup}>
            <Link
              to={url('register.provider.newuser')}
              aClassName={s.buttonSignUp}
            >
              Provider Sign Up
            </Link>
            <Link
              to={url('register.patient.newuser')}
              aClassName={s.buttonSignUp}
            >
              Client Sign Up
            </Link>
          </div>
        </Form>
      </OnBoardingBlock>
    );
  }
}

export default Login;
