import React from 'react';
import { pick, map } from 'lodash';

import Layout from '../../components/Layout/Layout';
import Provider from './MyNetworkView';
import HeaderComponent from '../../components/Header';
import { SUBMENU_PATIENT } from '../../constants';

function action({ params }) {
  map(SUBMENU_PATIENT, el => (el.params = pick(params, ['providerId'])));
  return {
    title: 'My-provider - provider view',
    component: (
      <Layout childrenContainerOnly>
        <HeaderComponent
          title={'My Provider'}
          back={'my-network'}
          body={SUBMENU_PATIENT}
        />
        <Provider providerId={params.providerId} />
      </Layout>
    ),
  };
}

export default action;
