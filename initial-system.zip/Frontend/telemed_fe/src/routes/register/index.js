import React from 'react';
import Register from './Register';

const title = 'Registration';

function action({ route, path, params }) {
  return {
    chunks: ['register'],
    title,
    component: (
      <Register
        title={title}
        parent={route.parent.path}
        path={path}
        hash={params.hash}
      />
    ),
  };
}

export default action;
