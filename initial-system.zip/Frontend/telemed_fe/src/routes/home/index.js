import React from 'react';
import Layout from '../../components/Layout';
import NoSSR from '../../components/NoSSR';
import MobileHeader from '../../components/Header/MobileHeader';

export default function() {
  return {
    chunks: ['home'],
    title: 'FullCircle',
    component: (
      <Layout childrenContainerOnly>
        <MobileHeader />
        <NoSSR
          element={() =>
            React.createElement(require('./components/index').default)}
        />
      </Layout>
    ),
  };
}
