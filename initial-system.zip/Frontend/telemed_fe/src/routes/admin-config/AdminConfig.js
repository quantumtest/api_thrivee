import React from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import HeaderComponent from '../../components/Header';
import List from './components/List';

import s from './Admin.scss';
import { getConfigs, getActualFee } from '../../actions/admin';

class AdminConfig extends React.Component {
  render() {
    return (
      <div>
        <HeaderComponent title="Configuration" />
        <div className={s.container}>
          <List type="configs" action={getConfigs} />
          <List type="systemFeeConfig" action={getActualFee} />
        </div>
      </div>
    );
  }
}

export default withStyles(s)(AdminConfig);
