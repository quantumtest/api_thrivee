import React, { Component } from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import { pick } from 'lodash';
import NoSSR from '../../components/NoSSR';

import form from '../../theme/form.glob.scss';
import main from '../../theme/main.glob.scss';

@withStyles(form, main)
class Steps extends Component {
  render() {
    return (
      <NoSSR
        element={() =>
          React.createElement(
            require('./components/index').default,
            pick(this.props, ['step', 'path']),
          )}
      />
    );
  }
}

export default Steps;
