import React from 'react';
import Steps from './Steps';

const title = 'Steps Registration';

function action({ path, params }) {
  return {
    chunks: ['register'],
    title,
    component: <Steps title={title} path={path} step={params.step} />,
  };
}

export default action;
