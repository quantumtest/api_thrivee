import React, { Component } from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { pick } from 'lodash';
import { Flex, Box } from 'reflexbox';

import { Loader, Dimmer } from 'semantic-ui-react';

import ActionError from '../../components/ActionError';
import Activity from './components/Activity';
import Calendar from './components/Calendar';

import s from './styles.scss';
import semanticS from './styles.glob.scss';
import semanticFormS from '../../theme/form.glob.scss';

import { getMyAccount } from '../../actions/user';

const mapStateToProps = ({ runtime }) =>
  pick(runtime, ['myProfileLoaded', 'myProfileError']);

const mapDispatchToProps = dispatch =>
  bindActionCreators({ getMyAccount, dispatch }, dispatch);

@withStyles(semanticS, semanticFormS, s)
@connect(mapStateToProps, mapDispatchToProps)
class Schedule extends Component {
  static propTypes = {
    dispatch: PropTypes.func,
    query: PropTypes.object,
    path: PropTypes.string,
    myProfileLoaded: PropTypes.bool,
    myProfileError: PropTypes.bool,
    getMyAccount: PropTypes.func.isRequired,
  };

  componentDidMount() {
    this.props.getMyAccount();
  }

  componentWillUnmount() {
    this.props.dispatch({ type: 'RESET_SCHEDULE' });
    this.props.dispatch({
      type: 'RESET_RUNTIME',
      names: ['scheduleNotifs'],
    });
  }

  render() {
    if (this.props.myProfileError) {
      return <div>Error loading profile</div>;
    }
    if (!this.props.myProfileLoaded) {
      return (
        <Dimmer active inverted>
          <Loader inverted content="Loading calendar" />
        </Dimmer>
      );
    }
    return (
      <Flex wrap>
        <Box w={[1, 1, 2 / 3, 3 / 4]} className={s.CalendarContainer}>
          <Calendar {...pick(this.props, ['query', 'path'])} />
        </Box>

        <Box w={[1, 1, 1 / 3, 1 / 4]}>
          <ActionError name="scheduleNotifs">
            <Activity />
          </ActionError>
        </Box>
      </Flex>
    );
  }
}

export default Schedule;
