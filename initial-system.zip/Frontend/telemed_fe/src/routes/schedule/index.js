import React from 'react';
import Layout from '../../components/Layout';
import NoSSR from '../../components/NoSSR';

export default function({ query, path }) {
  return {
    chunks: ['schedule'],
    title: 'Schedule',
    component: (
      <Layout noContainer>
        <NoSSR
          element={() =>
            React.createElement(require('./Schedule').default, { query, path })}
        />
      </Layout>
    ),
  };
}
