import React from 'react';
import Layout from '../../components/Layout';
import Eligibility from './Eligibility';
import ActionLoader from '../../components/ActionLoader';
import { getPatient } from '../../actions/user';

function action({ params, url: path }) {
  const getPatientL = () => getPatient(params.patientId);
  return {
    chunks: ['patient'],
    title: 'Patient - Eligibility',
    component: (
      <Layout childrenContainerOnly>
        <ActionLoader
          notCheckLen
          relative
          paddedWrapper
          checkAction
          name="patientProfile"
          action={getPatientL}
        >
          <Eligibility {...params} path={path} />
        </ActionLoader>
      </Layout>
    ),
  };
}

export default action;
