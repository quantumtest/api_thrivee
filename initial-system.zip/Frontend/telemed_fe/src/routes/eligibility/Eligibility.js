import React, { Component } from 'react';
import { pick, get } from 'lodash';
import { connect } from 'react-redux';

import NoSSR from '../../components/NoSSR';

const mapStateToProps = state => ({
  insurances: get(state.runtime, 'patientProfileData.insurance'),
});

@connect(mapStateToProps)
class Eligibility extends Component {
  render() {
    return (
      <NoSSR
        element={() =>
          React.createElement(
            require('./components/index').default,
            pick(this.props, ['patientId', 'providerId', 'path', 'insurances']),
          )}
      />
    );
  }
}

export default Eligibility;
