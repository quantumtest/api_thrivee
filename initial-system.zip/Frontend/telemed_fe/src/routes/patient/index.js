import React from 'react';
import { pick } from 'lodash';
import NoSSR from '../../components/NoSSR';
import Layout from '../../components/Layout';

function action({ params }) {
  return {
    chunks: ['patient'],
    title: 'Patient',
    component: (
      <Layout childrenContainerOnly>
        <NoSSR
          element={() =>
            React.createElement(
              require('./components/index').default,
              pick(params, ['patientId']),
            )}
        />
      </Layout>
    ),
  };
}

export default action;
