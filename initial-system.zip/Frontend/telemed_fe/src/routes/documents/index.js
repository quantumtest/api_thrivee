import React from 'react';
import Layout from '../../components/Layout';
import NoSSR from '../../components/NoSSR';

import HeaderComponent from '../../components/Header';
import { SETTINGS_PROVIDER } from '../../constants';

const title = 'Documents';

export default function() {
  return {
    chunks: ['documents'],
    title,
    component: (
      <Layout childrenContainerOnly>
        <HeaderComponent title="Settings" body={SETTINGS_PROVIDER} />
        <NoSSR
          element={() => React.createElement(require('./Documents').default)}
        />
      </Layout>
    ),
  };
}
