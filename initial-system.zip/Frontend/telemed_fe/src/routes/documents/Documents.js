import React, { Component } from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import cn from 'classnames';
import { connect } from 'react-redux';
import { Flex, Box } from 'reflexbox';

import ActionLoader from '../../components/ActionLoader';
import { getConsents } from '../../actions/other';
import DocumentsContent from './components/Content';

import a from './Documents.scss';
import b from '../../components/SettingImportantContainer/style.scss';

@withStyles(a, b)
@connect()
class Documents extends Component {
  render() {
    return (
      <Flex mt="10px" p={1} wrap>
        <Box w={[1, 3 / 5, 1 / 2, 2 / 5]} p={[0, 2]}>
          <div className={cn([a.container, b.billingBlock])}>
            <ActionLoader
              badWrapper={text => (
                <span className={a.errorContainer}>{text}</span>
              )}
              clearOnUnmount
              name="consents"
              notCheckLen
              action={getConsents}
            >
              <DocumentsContent />
            </ActionLoader>
          </div>
        </Box>
      </Flex>
    );
  }
}

export default Documents;
