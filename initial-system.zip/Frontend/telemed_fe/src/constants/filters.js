export const AGE_FILTER = [0, 100];
export const RATE_FILTER = [0, 1500];
export const LOCATION_FILTER = 3000;
export const GENDER_FILTER = [
  { value: 'MALE', text: 'Male' },
  { value: 'FEMALE', text: 'Female' },
];
export const PROVIDER_TYPE_FILTER = [
  { value: 'MHP', text: 'Mental Health Prescriber' },
  { value: 'MHT', text: 'Mental Health Therapist' },
  // { value: 2, text: 'PCP' },
  // { value: 3, text: 'PCE' },
];
export const FORM_FILTER = [
  { name: 'street', label: 'Street' },
  { name: 'city', label: 'City' },
  { name: 'zip', label: 'Zip' },
];
export const DEMOGRAPHICS_FILTER = [
  {
    filter: 'sexualOrientation',
    path: '/demographics/all/sexualorientations',
    title: 'Sexual orientation',
  },
  {
    filter: 'ageRange',
    path: '/demographics/all/ageranges',
    title: 'Age range',
  },
  {
    filter: 'ethnicity',
    path: '/demographics/all/ethnicities',
    title: 'Ethnicity',
  },
  {
    filter: 'modality',
    path: '/demographics/all/modalities',
    title: 'Modality',
  },
];
