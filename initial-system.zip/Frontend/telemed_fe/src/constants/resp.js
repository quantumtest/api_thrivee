import { values } from 'lodash';

export const UI_BP = {
  mob: 608,
  tab: 960,
  desc: 1280,
  TV: 1504,
};

export const UI_BREAKPOINTS_EM = values(UI_BP).map(val => Math.round(val / 16));

export const UI_BREAKPOINTS = [
  480,
  UI_BP.mob,
  840,
  UI_BP.tab,
  UI_BP.desc,
  1440,
  UI_BP.TV,
  1600,
];
