export const GOOGLE_MAPS_KEY = 'AIzaSyBo93Zz9_Es8OuPU9_6_AWv7lvOP6viY9E';
