export const SETTINGS_PROVIDER = [
  { text: 'My Profile', name: 'profile' },
  { text: 'Account', name: 'account' },
  { text: 'Billing Info', name: 'billing-info' },
  { text: 'Documents', name: 'documents', userType: ['provider'] },
  // { text: 'Practice', name: 'practice' },
];

export const SETTINGS_ADMIN = [{ text: 'Account', name: 'account' }];

export const SUBMENU_PATIENT = [
  {
    text: 'Conference History',
    name: 'my-provider.conference-history',
    userType: ['patient'],
  },
];

export const SUB_MENU_PROVIDER = [
  {
    text: 'Profile',
    name: 'my-patients.view',
  },
  {
    text: 'Eligibility',
    name: 'my-patients.eligibility',
  },
  {
    text: 'Conference History',
    name: 'my-patients.conference-history',
  },
  {
    text: 'Diagnostic Impressions',
    name: 'my-patients.diagnostic-impressions',
  },
  {
    text: 'Notes',
    name: 'my-patients.notes',
  },
];
