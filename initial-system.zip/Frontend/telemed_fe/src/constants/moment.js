export const REQUEST_DATE_TIME = 'YYYY-MM-DDTHH:mm:ssZ';
export const SET_DATE_TIME = 'YYYY-MM-DDTHH:mm';
export const DATE_DASH = 'YYYY-MM-DD';
export const DATE_LABEL = 'MM.DD.YYYY';
export const DATE_PICKER_LABEL = 'MM.dd.yyyy';
export const DATE_TIME_LABEL = 'MM.DD.YYYY h:mm A';
export const TIME_LABEL = 'h:mm A';
export const DAY_LABEL = 'ddd, D MMM';
