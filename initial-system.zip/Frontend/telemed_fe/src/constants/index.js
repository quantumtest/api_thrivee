export * from './moment';
export * from './headersMenu';
export * from './filters';
export * from './resp';
export * from './keys';
export * from './options';

export const SET_LAYOUT = 'SET_LAYOUT';
export const TOGGLE_SIDEBAR = 'TOGGLE_SIDEBAR';
export const SET_RUNTIME_VARIABLE = 'SET_RUNTIME_VARIABLE';
export const SET_RUNTIME_VARIABLES = 'SET_RUNTIME_VARIABLES';
export const START_LOAD = 'START_LOAD';
export const END_LOAD = 'END_LOAD';
export const ERROR_LOAD = 'ERROR_LOAD';
export const CUSTOM_ERROR_LOAD = 'CUSTOM_ERROR_LOAD';
export const SET_SCHEDULE = 'SET_SCHEDULE';
export const RESET_SCHEDULE = 'RESET_SCHEDULE';

export const ADD_PAGE_LOAD = 'ADD_PAGE_LOAD';
export const REMOVE_ITEM_LOAD = 'REMOVE_ITEM_LOAD';
export const LOAD_FIRST = 'LOAD_FIRST';
export const LOAD_FIRST_WITHOUT_BACKGROUND = 'LOAD_FIRST_WITHOUT_BACKGROUND';

export const START_LOAD_PAGE = 'START_LOAD_PAGE';
export const END_LOAD_PAGE = 'END_LOAD_PAGE';
export const RESET_RUNTIME = 'RESET_RUNTIME';

export const PROVIDER_TYPE = 'provider';
export const PATIENT_TYPE = 'patient';
export const ADMIN_TYPE = 'admin';

export const SERVER_PROVIDER_TYPE = 'PROVIDER';
export const SERVER_PATIENT_TYPE = 'PATIENT';
export const SERVER_ADMIN_TYPE = 'ADMIN';

export const ID_SELF_INSURANCE = 1;

export const SYS_USER = 1;
export const SYS_MSNGR = 8;
export const LOGOUT_TIME = 7 * 60 * 1000;
export const ACTIVITY_EVENTS = [
  'click',
  'resize',
  'change',
  'scroll',
  'keypress',
  'keydown',
];
export const DEF_CURRENCY_FORMAT = '0,0.00';
export const NO_AVATAR_URL = '/assets/images/noavatar.png';

export const ALLOW_CHANGE_APPOINTMENT_TYPES = ['requested', 'accepted'];
