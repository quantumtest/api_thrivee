import generateUrls from 'universal-router/generateUrls';
import qs from 'qs';

import router from './router';
import history from './history';

const urlBack = generateUrls(router, { stringifyQueryParams: qs.stringify });

const url = (path, params) => urlBack(path, params);

export { url };

const push = (path, params) => history.push(url(path, params));
export default push;
