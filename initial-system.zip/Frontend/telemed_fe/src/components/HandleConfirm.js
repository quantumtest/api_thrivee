import React, { Component } from 'react';
import { Confirm } from 'semantic-ui-react';
import PropTypes from 'prop-types';

export default class HandleConfirmDelete extends Component {
  static propTypes = {
    fields: PropTypes.object,
    routePath: PropTypes.string,
    index: PropTypes.number,
  };

  state = {
    openRemove: false,
  };

  open = () => this.setState({ openRemove: true });

  handleCancel = () => this.setState({ openRemove: false });

  handleConfirm = () => {
    this.setState({ openRemove: false });
    this.props.fields.remove(this.props.index);
    setTimeout(() => {
      const el = document.querySelector(
        `#${this.props.routePath} .js-save-list-btn`,
      );
      if (el) el.click();
    }, 300);
  };

  render() {
    return (
      <Confirm
        key="confirm"
        open={this.state.openRemove}
        onCancel={this.handleCancel}
        onConfirm={this.handleConfirm}
      />
    );
  }
}
