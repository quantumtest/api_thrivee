import moment from 'moment';

import BigCalendar from '../react-big-calendar/src/Calendar';
import withDragAndDrop from '../react-big-calendar/src/addons/dragAndDrop';

BigCalendar.momentLocalizer(moment);
const DragAndDropCalendar = withDragAndDrop(BigCalendar);

export default DragAndDropCalendar;
