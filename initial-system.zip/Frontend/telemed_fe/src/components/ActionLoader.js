import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';

import { Header, Loader } from 'semantic-ui-react';
// TODO : use notCheckLen, data
const mapStateToProps = (
  { runtime },
  { name, simpleCheckData, hasAllData },
) => {
  if (!Array.isArray(name)) {
    name = [name];
  }
  if (simpleCheckData && !hasAllData) {
    hasAllData = name.every(item => runtime[`${item}Data`]);
  }
  return {
    hasAllData,
    loaded: name.every(item => runtime[`${item}Loaded`]),
    error: name.some(item => runtime[`${item}Error`]),
  };
};

@connect(mapStateToProps)
class ActionLoader extends Component {
  static propTypes = {
    children: PropTypes.node,
    loaded: PropTypes.bool,
    notInline: PropTypes.bool,
    notCheckLen: PropTypes.bool,
    clearOnUnmount: PropTypes.bool,
    checkAction: PropTypes.bool,
    paddedWrapper: PropTypes.bool,
    simpleCheckData: PropTypes.bool,
    hasAllData: PropTypes.bool,
    errorMsg: PropTypes.string,
    loadingMsg: PropTypes.string,
    data: PropTypes.array,
    wrapper: PropTypes.func,
    badWrapper: PropTypes.func,
    name: PropTypes.string.isRequired, // eslint-disable-line
  };

  static defaultProps = {
    wrapper: content => <div>{content}</div>,
    data: [],
    errorMsg: 'Error loading',
    noResultsMsg: 'No results found',
  };

  constructor(props) {
    super(props);
    this.wrapper = props.wrapper;
    if (this.props.relative) {
      this.wrapper = content => (
        <div className="default-wrapper">{content}</div>
      );
    }
    this.badWrapper = props.badWrapper;
    if (!props.badWrapper) {
      this.badWrapper = content =>
        this.wrapper(<Header as="h4">{content}</Header>);
    }
    if (this.props.paddedWrapper) {
      this.badWrapper = content => (
        <div className="padded-wrapper">
          <Header as="h4">{content}</Header>
        </div>
      );
    }
  }

  componentDidMount() {
    this.startLoad();
  }

  componentDidUpdate(prevProps) {
    if (this.props.checkAction && prevProps.action !== this.props.action) {
      this.startLoad();
    }
  }

  componentWillUnmount() {
    if (this.props.clearOnUnmount) {
      let names = this.props.name;
      if (!Array.isArray(names)) {
        names = [names];
      }
      this.props.dispatch({
        type: 'RESET_RUNTIME',
        names,
      });
    }
  }

  get loader() {
    return (
      <Loader
        active
        inline={this.props.notInline ? '' : 'centered'}
        className={this.props.loaderClassName}
        content={this.props.loadingMsg || 'Loading'}
      />
    );
  }

  startLoad = () => {
    let actions = this.props.action;
    if (actions) {
      if (!Array.isArray(actions)) {
        actions = [actions];
      }
      actions.forEach(action => this.props.dispatch(action()));
    }
  };

  render() {
    if (this.props.error) {
      return this.badWrapper(this.props.errorMsg);
    }
    if (this.props.loaded) {
      if (this.props.simpleCheckData) {
        if (!this.props.hasAllData) {
          return this.badWrapper(this.props.noResultsMsg);
        }
      } else if (!this.props.notCheckLen && !this.props.data.length) {
        return this.badWrapper(this.props.noResultsMsg);
      }
      return this.props.children;
    }
    if (this.props.paddedWrapper) {
      return <div className="padded-wrapper">{this.loader}</div>;
    }
    return this.wrapper(this.loader);
  }
}

export default ActionLoader;
