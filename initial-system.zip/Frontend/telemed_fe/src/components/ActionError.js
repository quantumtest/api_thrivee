import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';

import { Header } from 'semantic-ui-react';

const mapStateToProps = ({ runtime }, props) => ({
  error: runtime[`${props.name}Error`],
});

@connect(mapStateToProps)
class ActionError extends Component {
  static propTypes = {
    children: PropTypes.node,
    errorMsg: PropTypes.string,
  };

  render() {
    if (this.props.error) {
      return <Header as="h4">{this.props.errorMsg || 'Error loading'}</Header>;
    }
    return this.props.children;
  }
}

export default ActionError;
