/* @flow */

import React from 'react';
import PropTypes from 'prop-types';

declare var __BROWSER__: boolean;

export default class NoSSR extends React.Component {
  static propTypes = {
    children: PropTypes.oneOfType([PropTypes.node, PropTypes.func]),
    onSSR: PropTypes.oneOfType([PropTypes.node, PropTypes.func]),
    element: PropTypes.func,
  };

  static defaultProps = {
    children: null,
    onSSR: null,
  };

  state = {
    canRender: false,
  };

  componentDidMount() {
    const { canRender } = this.state;
    if (canRender) return;
    // eslint-disable-next-line react/no-did-mount-set-state
    requestAnimationFrame(() => this.setState({ canRender: true }));
  }

  render() {
    if (!this.state.canRender) {
      return this.props.onSSR;
    }
    if (this.props.element) {
      return this.props.element();
    }
    return this.props.children;
  }
}
