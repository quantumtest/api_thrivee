import { mapKeys, get, set } from 'lodash';

const checkArray = (values, params) => {
  const errors = {};
  mapKeys(params, (validators, key) => {
    validators.forEach(validate => {
      const error = validate(get(values, key), key, values);
      if (error) {
        set(errors, key, error);
      }
    });
  });
  return errors;
};

export { checkArray }; // eslint-disable-line
