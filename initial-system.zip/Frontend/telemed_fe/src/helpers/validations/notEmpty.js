const notEmpty = (value /* , name, allValues */) => {
  if (typeof value === 'number') {
    if (value === undefined) {
      return `Please, fill`;
    }
    return;
  }
  if (!value) {
    return `Please, fill`;
  }
};

export { notEmpty };// eslint-disable-line
