const isValidNpi = npi => {
  let tmp;
  let sum;
  let i;
  let j;
  i = npi.length;
  if (i === 15 && npi.indexOf('80840', 0, 5) === 0) sum = 0;
  else if (i === 10) sum = 24;
  else return false;
  j = 0;
  while (i !== 0) {
    tmp = npi.charCodeAt(i - 1) - '0'.charCodeAt(0);
    if (j++ % 2 !== 0 && (tmp <<= 1) > 9) {
      tmp -= 10;
      tmp++;
    }
    sum += tmp;
    i--;
  }
  if (sum % 10 === 0) return true;
  return false;
};

const checkDigitNpi = npi9 => {
  let tmp;
  let sum;
  let i;
  let j;
  i = npi9.length;
  if (i === 14 && npi9.indexOf('80840', 0, 5) === 0) sum = 0;
  else if (i === 9) sum = 24;
  else {
    return '!';
  }

  j = 1;
  while (i !== 0) {
    tmp = npi9.charCodeAt(i - 1) - '0'.charCodeAt(0);
    if (j++ % 2 !== 0 && (tmp <<= 1) > 9) {
      tmp -= 10;
      tmp++;
    }
    sum += tmp;
    i--;
  }
  return String.fromCharCode((10 - sum % 10) % 10 + 48);
};

export { checkDigitNpi, isValidNpi };
