import moment from 'moment';
import { DAY_LABEL } from '../../constants';

const updateDateYear = (dest, source) => {
  dest.dayOfYear(source.dayOfYear());
  dest.year(source.year());
  return dest;
};

const updateMinHour = (dest, source) => {
  dest.minute(source.minute());
  dest.hour(source.hour());
  return dest;
};

const getDayLabel = (date, now = window.currentTimeBrZone.clone()) => {
  date = moment(date);
  const diff = date.diff(now, 'day');
  switch (diff) {
    case 0:
      return 'Today';
    case 1:
      return 'Yesterday';
  }
  return date.format(DAY_LABEL);
};

const getDuration = (started, finished) => {
  let hours = moment(finished).diff(moment(started), 'hour');
  let minutes = moment(finished).diff(moment(started), 'minutes');
  hours = Math.floor(minutes / 60);
  minutes %= 60;
  if (hours <= 0) {
    return `${minutes}min`;
  }
  if (minutes > 0) {
    return `${hours}h ${minutes}min`;
  }
  return `${hours}h`;
};

const checkAge = (time, type) => {
  const today = new Date();
  if (type === 'provider')
    return time > new Date((today.getFullYear() - 13).toString());
  return time > today;
};

export { updateDateYear, updateMinHour, getDayLabel, getDuration, checkAge };
