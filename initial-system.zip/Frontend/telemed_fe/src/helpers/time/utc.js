import moment from 'moment';
import { REQUEST_DATE_TIME, SET_DATE_TIME, DATE_DASH } from '../../constants';

const sentParseZone = (date, format = SET_DATE_TIME) =>
  moment(moment(date).format(format), format);

const forSend = (data, timeZone = 0) => {
  const m = moment(data)
    .clone()
    .utcOffset(timeZone, true)
    .utcOffset(0);
  return m;
};

const forReceive = (date, timeZone = 0) => {
  const m = moment(date)
    .clone()
    .utcOffset(timeZone);
  return sentParseZone(m);
};

export const date = (val, { format }) => moment(val, format).toDate();

export const dateReceive = (val, { timeZone }) =>
  forReceive(val, timeZone).toDate();

export const dateSend = (val, timeZone) => {
  if (!val) return '';
  const ans = forSend(val, timeZone).format(REQUEST_DATE_TIME);
  if (ans === 'Invalid date') {
    return '';
  }
  return ans;
};

export const dateNoTimeSend = val => {
  if (!val) return '';
  const ans = moment(val, DATE_DASH)
    .clone()
    .format(REQUEST_DATE_TIME);
  if (ans === 'Invalid date') {
    return '';
  }
  return ans;
};

export const dateNoTimeReceive = val => moment(val, DATE_DASH);

export const dateNoTimeFormat = (val, format) => {
  const ans = dateNoTimeReceive(val);
  if (!ans.isValid()) {
    return '';
  }
  return ans.format(format);
};

export { forSend, forReceive, sentParseZone };
