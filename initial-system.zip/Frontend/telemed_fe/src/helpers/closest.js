const closest = (node, css) => {
  while (node) {
    if (node.matches(css)) return node;
    node = node.parentElement;
  }
  return null;
};

export default closest;
