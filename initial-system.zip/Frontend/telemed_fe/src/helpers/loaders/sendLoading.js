import { toastrError } from '../loaders';
import { send } from '../../api/utils';

const sendLoadingPromise = async (
  setLoading,
  promise,
  { timeout = 200, checkError = true } = {},
) => {
  const timeoutFunc = setTimeout(() => setLoading(true), timeout);
  let resp;
  try {
    resp = await promise;
  } catch (e) {
    console.error(e);
    if (checkError) {
      toastrError(e);
    }
    throw e;
  } finally {
    clearTimeout(timeoutFunc);
    setLoading(false);
  }
  return resp;
};

const sendLoading = (setLoading, url, data, opt) =>
  sendLoadingPromise(setLoading, send({ url, data }), opt);

export { sendLoading, sendLoadingPromise };
