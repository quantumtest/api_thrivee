import { toastr } from 'react-redux-toastr';
import { get } from 'lodash';

let isSending = false;
const DEFAULT_ERROR_MSG = 'Something went wrong';

const getErrorMsg = (e, defaultErrorMsg = DEFAULT_ERROR_MSG) =>
  get(e, 'response.data.message') ||
  get(e, 'message') ||
  (typeof e === 'string' ? e : defaultErrorMsg);

const toastrError = (e, defaultErrorMsg) =>
  toastr.error(getErrorMsg(e, defaultErrorMsg));

const sendWithNotifs = async (
  request,
  {
    name,
    successMsg = 'Successfully saved',
    warningMsg = 'Loading, please wait',
    showError,
    defaultFunc = () => null,
  } = {},
) => {
  if (name) {
    if (warningMsg === 'Loading, please wait') {
      warningMsg = `Loading ${name}, please wait`;
    }
    if (successMsg === 'Successfully saved') {
      successMsg = `Successfully ${name} saved`;
    }
  }
  if (isSending) {
    toastr.warning(warningMsg);
    return;
  }
  isSending = true;
  if (typeof request === 'function') {
    request = request();
  }
  let resp;
  try {
    resp = await request;
    if (successMsg) {
      toastr.success(successMsg);
    }
  } catch (e) {
    if (showError) {
      console.warn(e);
      toastrError(e);
    }
    throw e;
  } finally {
    isSending = false;
    defaultFunc();
  }
  return resp;
};

export { sendWithNotifs, getErrorMsg, toastrError };
