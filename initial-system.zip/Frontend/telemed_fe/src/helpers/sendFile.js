import { pick, cloneDeep } from 'lodash';
import axios from 'axios';

import { send } from '../api/utils';
import { toastrError } from './loaders';

const LOCAL_FILE_PARAMS = [
  'lastModified',
  'lastModifiedDate',
  'name',
  'preview',
  'size',
  'type',
];

const demyFunc = d => d;

async function sendFile(file, { url, adaptData = demyFunc, headers }) {
  const preview = file.preview;
  const id = preview.substr(preview.lastIndexOf('/') + 1);
  if (this.state.loadingItems[id]) {
    console.warn('has that id', cloneDeep(this.state.loadingItems));
    return;
  }
  let dataForSend = new FormData();
  const localItem = pick(file, LOCAL_FILE_PARAMS);
  localItem.stop = () => 'not';
  localItem.id = id;
  dataForSend.append('file', file);
  setTimeout(() => {
    this.setState({
      loadingItems: {
        ...this.state.loadingItems,
        [id]: localItem,
      },
      loaderPercent: {
        ...this.state.loaderPercent,
        [id]: 0,
      },
    });
  }, 0);
  dataForSend = adaptData(dataForSend);
  let resp;
  let err;
  try {
    resp = await send({
      url,
      data: dataForSend,
      isFormData: true,
      headers,
      onUploadProgress: progressEvent => {
        const procents =
          Math.floor(progressEvent.loaded * 100 / progressEvent.total) || 0;
        window.lastActivityTime = Date.now();
        if (procents > 100) {
          return;
        }
        this.state.loaderPercent[id] = procents;
        this.setState({
          loaderPercent: cloneDeep(this.state.loaderPercent),
        });
      },
      cancelToken: new axios.CancelToken(_stop => (localItem.stop = _stop)),
    });
  } catch (e) {
    console.error(e);
    err = e;
    if (!axios.isCancel(e)) {
      toastrError(e);
    }
    throw new Error({ err, localItem });
  } finally {
    const loadingItems = this.state.loadingItems;
    delete loadingItems[localItem.id];
    this.setState({ loadingItems: { ...loadingItems } });
  }
  return { localItem, data: resp.data };
}

export { sendFile };
