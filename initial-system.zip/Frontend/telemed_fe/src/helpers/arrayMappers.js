import { nameConcat } from './defaultAdapter/name';

const universalMapArray = arr =>
  arr.map(item => ({
    key: item.id,
    value: item.id,
    text: item.name,
  }));

const diagnosticImpressionMapArray = arr =>
  arr.map(item => ({
    key: item.id,
    value: item.value,
    text: `${item.value} ${item.name}`,
  }));

const generateMapUsers = keyName => users =>
  users.map(user => {
    const key = user[keyName];
    let { avatar } = user;
    avatar = avatar || {};
    return {
      text: nameConcat(user),
      value: key,
      key,
      image: {
        avatar: true,
        src: avatar.base64 || '../../../../assets/images/noavatar.png',
      },
    };
  });

const mapUsers = generateMapUsers('accountId');

const statesMapArray = arr =>
  arr.map(item => ({
    key: item.id,
    value: item.id,
    text: item.longName,
  }));

const timeZonesArray = arr =>
  arr.map(item => ({
    key: item.id,
    value: item.id,
    text: `${item.shortName} ( ${item.offset}:00 )`,
  }));

const sessionMapArray = arr =>
  arr.map(item => ({
    key: item.id,
    value: item.id,
    text: `${item.value} minutes`,
  }));

const languagesMapArray = arr =>
  arr.map(item => ({
    key: item.id,
    value: item.id,
    text: item.value,
  }));

export {
  statesMapArray,
  universalMapArray,
  timeZonesArray,
  sessionMapArray,
  languagesMapArray,
  diagnosticImpressionMapArray,
  mapUsers,
};
