import { views } from './utils/constants';
import Month from './Month';
import Day from './Day';
import Week from './Week';
import WorkWeek from './WorkWeek';
import Agenda from './Agenda';

const VIEWS = {
  [views.DAY]: Day,
  [views.WEEK]: Week,
  [views.MONTH]: Month,
  [views.WORK_WEEK]: WorkWeek,
  [views.AGENDA]: Agenda,
};

export default VIEWS;
