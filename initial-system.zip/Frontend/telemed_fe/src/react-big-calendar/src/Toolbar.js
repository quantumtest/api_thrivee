import PropTypes from 'prop-types';
import React from 'react';
import cn from 'classnames';
import { Button, Label } from 'semantic-ui-react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import DatePicker from 'element-react/dist/npm/es5/src/date-picker/DatePicker';
import { capitalize } from 'lodash';
import message from './utils/messages';

import navCSS from '../../components/Navigation/Navigation.scss'
import SidebarBtn from '../../components/ToggleSidebar';

@withStyles(navCSS)
class Toolbar extends React.Component {
  static contextTypes = {
    myZone: PropTypes.number.isRequired,
    myZoneName: PropTypes.string.isRequired,
  };

  static propTypes = {
    view: PropTypes.string.isRequired,
    views: PropTypes.arrayOf(PropTypes.string).isRequired,
    label: PropTypes.node.isRequired,
    messages: PropTypes.object,
    onNavigate: PropTypes.func.isRequired,
    onViewChange: PropTypes.func.isRequired,
    onDrillDown: PropTypes.func.isRequired,
  };

  toggleFlat = () => !this.pick.state.pickerVisible &&
    setTimeout(() => this.pick.togglePickerVisible(), 0);

  get selectionMode(){
    switch(this.props.view){
      case 'day':
        return;
      case 'agenda':
        return 'day';
      default:
        return this.props.view;
    }
  }

  render() {
    let { messages, label } = this.props;

    messages = message(messages);

    // .flatpickr.open(null, $0)
    return (
      <div className="rbc-toolbar">
        <SidebarBtn />
        <span className={navCSS.timeZoneLabel}>
          {this.context.myZoneName + ' ' + this.context.myZone + ':00'}
        </span>
        <span className="rbc-toolbar-label">
          <DatePicker
            today={this.props.today}
            value={this.props.date}
            selectionMode={this.selectionMode}
            ref={pick => this.pick = pick}
            onChange={v => {
              console.info(v);
              this.props.onDrillDown(v);
            }}
          />
          <span onClick={this.toggleFlat}>{label}</span>
        </span>
        <span className={navCSS.linksContainer}>{this.viewNamesGroup(messages)}</span>
      </div>
    );
  }

  navigate = action => this.props.onNavigate;

  view = view => {
    this.props.onViewChange(view);
  };

  viewNamesGroup(messages) {
    const viewNames = this.props.views;
    const view = this.props.view;

    if (viewNames.length > 1) {
      return viewNames.map(name => {
        return (
          <span
            key={name}
            className={navCSS.link}
          >
            <span className={cn({"active-link": view === name})}>
              <Button
                type="button"
                className={navCSS.linkButton}
                onClick={this.view.bind(null, name)}
              >
                {capitalize(messages[name])}
              </Button>
            </span>
        </span>
        )
      });
    }
  }
}

export default Toolbar;
