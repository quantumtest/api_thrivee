import PropTypes from 'prop-types';
import React from 'react';
import dates from './utils/dates';
import TimeGrid from './TimeGrid';
import { navigate } from './utils/constants';

class Day extends React.Component {
  static propTypes = {
    date: PropTypes.instanceOf(Date).isRequired,
  };

  render() {
    const { date, ...otherProps } = this.props;
    const range = Day.range(date);

    return <TimeGrid {...otherProps} range={range} eventOffset={10} skipAllDay />;
  }
}

Day.navigate = (date, action) => {
  switch (action) {
    case navigate.PREVIOUS:
      return dates.add(date, -1, 'day');

    case navigate.NEXT:
      return dates.add(date, 1, 'day');

    default:
      return date;
  }
};

Day.range = date => [dates.startOf(date, 'day')];

export default Day;
