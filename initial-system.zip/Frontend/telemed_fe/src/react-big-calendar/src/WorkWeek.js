import PropTypes from 'prop-types';
import React from 'react';

import Week from './Week';
import TimeGrid from './TimeGrid';

class WorkWeek extends React.Component {
  static propTypes = {
    date: PropTypes.instanceOf(Date).isRequired,
  };

  static defaultProps = TimeGrid.defaultProps;

  render() {
    const { date, ...otherProps } = this.props;
    const range = WorkWeek.range(date, this.props);

    return <TimeGrid {...otherProps} range={range} eventOffset={15} />;
  }
}

WorkWeek.navigate = Week.navigate;

WorkWeek.range = (date, options) =>
  Week.range(date, options).filter(d => [6, 0].indexOf(d.getDay()) === -1);

export default WorkWeek;
