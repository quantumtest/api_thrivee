import PropTypes from 'prop-types';
import React from 'react';
import { findDOMNode } from 'react-dom';
import cn from 'classnames';

import Selection, { getBoundsForNode, isEvent } from './Selection';
import dates from './utils/dates';
import { isSelected } from './utils/selection';
import localizer from './localizer';

import { notify } from './utils/helpers';
import { accessor, elementType, dateFormat } from './utils/propTypes';
import { accessor as get } from './utils/accessors';

import getStyledEvents, {
  positionFromDate,
  startsBefore,
} from './utils/dayViewLayout';

import TimeColumn from './TimeColumn';

function snapToSlot(date, step) {
  const roundTo = 1000 * 60 * step;
  return new Date(Math.floor(date.getTime() / roundTo) * roundTo);
}

function startsAfter(date, max) {
  return dates.gt(dates.merge(max, date), max, 'minutes');
}

class DaySlot extends React.Component {
  static propTypes = {
    events: PropTypes.array.isRequired,
    step: PropTypes.number.isRequired,
    min: PropTypes.instanceOf(Date).isRequired,
    max: PropTypes.instanceOf(Date).isRequired,
    now: PropTypes.instanceOf(Date),

    rtl: PropTypes.bool,
    titleAccessor: accessor,
    allDayAccessor: accessor.isRequired,
    startAccessor: accessor.isRequired,
    endAccessor: accessor.isRequired,

    selectRangeFormat: dateFormat,
    eventTimeRangeFormat: dateFormat,
    culture: PropTypes.string,

    selected: PropTypes.object,
    selectable: PropTypes.oneOf([true, false, 'ignoreEvents']),
    eventOffset: PropTypes.number,

    onSelecting: PropTypes.func,
    onSelectSlot: PropTypes.func.isRequired,
    onSelectEvent: PropTypes.func.isRequired,

    className: PropTypes.string,
    dragThroughEvents: PropTypes.bool,
    eventPropGetter: PropTypes.func,
    dayWrapperComponent: elementType,
    eventComponent: elementType,
    eventWrapperComponent: elementType.isRequired,
  };

  static defaultProps = { dragThroughEvents: true };
  state = { selecting: false };

  componentDidMount() {
    this.props.selectable && this._selectable();
  }

  componentWillUnmount() {
    this._teardownSelectable();
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.selectable && !this.props.selectable) {
      this._selectable();
    }
    if (!nextProps.selectable && this.props.selectable) {
      this._teardownSelectable();
    }
  }

  render() {
    const {
      min,
      max,
      step,
      now,
      today,
      selectRangeFormat,
      culture,
      ...otherProps
    } = this.props;

    this._totalMin = dates.diff(min, max, 'minutes');

    const { selecting, startSlot, endSlot } = this.state;
    const style = this._slotStyle(startSlot, endSlot);

    const selectDates = {
      start: this.state.startDate,
      end: this.state.endDate,
    };

    return (
      <TimeColumn
        {...otherProps}
        className={cn('rbc-day-slot', dates.isToday(max, today) && 'rbc-today')}
        now={now}
        min={min}
        max={max}
        step={step}
      >
        {this.renderEvents()}

        {selecting && (
          <div className="rbc-slot-selection" style={style}>
            <span>
              {localizer.format(selectDates, selectRangeFormat, culture)}
            </span>
          </div>
        )}
      </TimeColumn>
    );
  }

  renderEvents = () => {
    const {
      events,
      min,
      max,
      culture,
      eventPropGetter,
      selected,
      eventTimeRangeFormat,
      eventComponent,
      eventWrapperComponent: EventWrapper,
      rtl: isRtl,
      step,
      startAccessor,
      endAccessor,
      titleAccessor,
    } = this.props;

    const EventComponent = eventComponent;

    const styledEvents = getStyledEvents({
      events,
      startAccessor,
      endAccessor,
      min,
      totalMin: this._totalMin,
      step,
    });

    return styledEvents.map(({ event, style }, idx) => {
      const start = get(event, startAccessor);
      const end = get(event, endAccessor);

      const continuesPrior = startsBefore(start, min);
      const continuesAfter = startsAfter(end, max);

      const title = get(event, titleAccessor);
      const label = localizer.format(
        { start, end },
        eventTimeRangeFormat,
        culture,
      );
      const _isSelected = isSelected(event, selected);

      if (eventPropGetter) {
        var { style: xStyle, className } = eventPropGetter(
          event,
          start,
          end,
          _isSelected,
        );
      }

      const { height, top, width, xOffset } = style;

      return (
        <EventWrapper event={event} key={`evt_${idx}`}>
          <div
            style={{
              ...xStyle,
              top: `${top}%`,
              height: `${height}%`,
              [isRtl ? 'right' : 'left']: `${Math.max(0, xOffset)}%`,
              width: `${width}%`,
            }}
            onClick={e => this._select(event, e)}
            className={cn('rbc-event', 'rbc-' + event.type, className, {
              'rbc-selected': _isSelected,
              'rbc-event-continues-earlier': continuesPrior,
              'rbc-event-continues-later': continuesAfter,
            })}
          >
            <div className="rbc-event-content">
              {EventComponent ? (
                <EventComponent event={event} title={title} />
              ) : (
                title
              )}
            </div>
          </div>
        </EventWrapper>
      );
    });
  };

  _slotStyle = (startSlot, endSlot) => {
    const top = startSlot / this._totalMin * 100;
    const bottom = endSlot / this._totalMin * 100;

    return {
      top: `${top}%`,
      height: `${bottom - top}%`,
    };
  };

  _selectable = () => {
    const node = findDOMNode(this);
    const selector = (this._selector = new Selection(() => findDOMNode(this)));

    const maybeSelect = box => {
      const onSelecting = this.props.onSelecting;
      const current = this.state || {};
      const state = selectionState(box);
      const { startDate: start, endDate: end } = state;

      if (onSelecting) {
        if (
          (dates.eq(current.startDate, start, 'minutes') &&
            dates.eq(current.endDate, end, 'minutes')) ||
          onSelecting({ start, end }) === false
        ) {
          return;
        }
      }

      this.setState(state);
    };

    let selectionState = ({ y }) => {
      const { step, min, max } = this.props;
      const { top, bottom } = getBoundsForNode(node);

      const mins = this._totalMin;

      const range = Math.abs(top - bottom);

      let current = (y - top) / range;

      current = snapToSlot(minToDate(mins * current, min), step);

      if (!this.state.selecting) {
        this._initialDateSlot = current;
      }

      const initial = this._initialDateSlot;

      if (dates.eq(initial, current, 'minutes')) {
        current = dates.add(current, step, 'minutes');
      }

      const start = dates.max(min, dates.min(initial, current));
      const end = dates.min(max, dates.max(initial, current));

      return {
        selecting: true,
        startDate: start,
        endDate: end,
        startSlot: positionFromDate(start, min, this._totalMin),
        endSlot: positionFromDate(end, min, this._totalMin),
      };
    };

    selector.on('selecting', maybeSelect);
    selector.on('selectStart', maybeSelect);

    selector.on('mousedown', box => {
      if (this.props.selectable !== 'ignoreEvents') return;

      return !isEvent(findDOMNode(this), box);
    });

    selector.on('click', box => {
      if (!isEvent(findDOMNode(this), box)) {
        this._selectSlot({ ...selectionState(box), action: 'click' });
      }

      this.setState({ selecting: false });
    });

    selector.on('select', rect => {
      if (this.state.selecting) {
        this._selectSlot({
          ...this.state,
          action: 'select',
          rect,
          stopSelecting: () => this.setState({ selecting: false })
        });
      }
    });
  };

  _teardownSelectable = () => {
    if (!this._selector) return;
    this._selector.teardown();
    this._selector = null;
  };

  _selectSlot = options => {
    let { startDate, endDate } = options;
    let current = startDate,
      slots = [];

    while (dates.lte(current, endDate)) {
      slots.push(current);
      current = dates.add(current, this.props.step, 'minutes');
    }

    notify(this.props.onSelectSlot, {
      slots,
      ...options,
    });
  };

  _select = (...args) => {
    notify(this.props.onSelectEvent, args);
  };
}

function minToDate(min, date) {
  let dt = new Date(date),
    totalMins = dates.diff(dates.startOf(date, 'day'), date, 'minutes');

  dt = dates.hours(dt, 0);
  dt = dates.minutes(dt, totalMins + min);
  dt = dates.seconds(dt, 0);
  return dates.milliseconds(dt, 0);
}

export default DaySlot;
