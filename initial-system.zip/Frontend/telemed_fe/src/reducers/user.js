export default function user(state = {}, action) {
  switch (action.type) {
    default:
      return state;
  }
}
