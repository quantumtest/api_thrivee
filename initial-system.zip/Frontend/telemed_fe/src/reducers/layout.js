import { SET_LAYOUT, TOGGLE_SIDEBAR } from '../constants';

export default function runtime(state = {}, action) {
  switch (action.type) {
    case SET_LAYOUT:
      return action.payload;
    case TOGGLE_SIDEBAR:
      return { ...state, openBar: !state.openBar };
  }
  return state;
}
