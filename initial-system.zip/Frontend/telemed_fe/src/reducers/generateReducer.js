import { cloneDeep } from 'lodash';

function generateReducer(name, defaultState = {}) {
  return (state = cloneDeep(defaultState), action) => {
    switch (action.type) {
      case `SET_${name}`:
        return {
          ...state,
          ...action.payload,
        };
      case `RESET_${name}`:
        return cloneDeep(defaultState);
      default:
        return state;
    }
  };
}

export default generateReducer;
