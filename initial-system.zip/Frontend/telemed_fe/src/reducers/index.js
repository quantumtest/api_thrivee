import { combineReducers } from 'redux';
import { reducer as toastr } from 'react-redux-toastr';
import { reducer as form } from 'redux-form';
import user from './user';
import runtime from './runtime';
import layout from './layout';
import generateReducer from './generateReducer';

export default combineReducers({
  user,
  runtime,
  toastr,
  layout,
  form,
  schedule: generateReducer('SCHEDULE'),
  scheduleConflict: generateReducer('SCHEDULE_CONFLICT'),
});
