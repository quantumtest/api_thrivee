import { differenceWith, isEqual, get, findIndex } from 'lodash';
import {
  SET_RUNTIME_VARIABLE,
  SET_RUNTIME_VARIABLES,
  START_LOAD,
  END_LOAD,
  ERROR_LOAD,
  ADD_PAGE_LOAD,
  LOAD_FIRST,
  LOAD_FIRST_WITHOUT_BACKGROUND,
  RESET_RUNTIME,
  CUSTOM_ERROR_LOAD,
  REMOVE_ITEM_LOAD,
} from '../constants';

export default function runtime(state = {}, action) {
  const name = action.name;
  const result = get(action.data, 'result') || action.data;
  const oldArray = state[`${name}Array`] || [];
  let names = action.names;
  if (action.name) {
    names = [action.name];
  }
  switch (action.type) {
    case SET_RUNTIME_VARIABLE:
      return {
        ...state,
        [action.payload.name]: action.payload.value,
      };
    case SET_RUNTIME_VARIABLES:
      return {
        ...state,
        ...action.payload,
      };
    case START_LOAD:
      return {
        ...state,
        [`${name}Loading`]: true,
        [`${name}Loaded`]: false,
        [`${name}Data`]: null,
        [`${name}Error`]: null,
      };
    case END_LOAD:
      return {
        ...state,
        [`${name}Loading`]: false,
        [`${name}Loaded`]: true,
        [`${name}Data`]: action.data,
        [`${name}Error`]: null,
      };
    case ERROR_LOAD:
      return {
        ...state,
        [`${name}Loading`]: false,
        [`${name}Loaded`]: true,
        [`${name}Data`]: null,
        [`${name}Error`]: action.error,
      };
    case CUSTOM_ERROR_LOAD:
      return {
        ...state,
        [`${name}Loading`]: false,
        [`${name}Loaded`]: true,
        [`${name}Error`]: action.error,
        ...action.payload,
      };
    case ADD_PAGE_LOAD:
      return {
        ...state,
        [`${name}Loading`]: false,
        [`${name}Loaded`]: true,
        [`${name}Data`]: action.data,
        [`${name}Array`]: oldArray.concat(result),
        [`${name}Error`]: null,
      };
    case REMOVE_ITEM_LOAD: //eslint-disable-line
      const index = findIndex(oldArray, action.data);
      if (index !== -1) {
        oldArray.splice(index, 1);
      } else {
        console.warn('no item found in REMOVE_ITEM_LOAD');
      }
      return {
        ...state,
        [`${name}Loading`]: false,
        [`${name}Loaded`]: true,
        [`${name}Array`]: oldArray.slice(),
        [`${name}Error`]: null,
      };
    case LOAD_FIRST:  //eslint-disable-line
      const oldData = state[`${name}Array`] || [];
      const diff = differenceWith(result, oldData, isEqual);
      return {
        ...state,
        [`${name}Loading`]: false,
        [`${name}Loaded`]: true,
        [`${name}Array`]: diff.concat(oldData),
        [`${name}Data`]: action.data,
        [`${name}Error`]: null,
      };
    case LOAD_FIRST_WITHOUT_BACKGROUND:
      return {
        ...state,
        [`${name}Loading`]: false,
        [`${name}Loaded`]: true,
        [`${name}Array`]: action.data.result,
        [`${name}Data`]: action.data,
        [`${name}Error`]: null,
      };
    case RESET_RUNTIME:
      if (names) {
        names.forEach(item => {
          state[`${item}Loading`] = undefined;
          state[`${item}Loaded`] = undefined;
          state[`${item}Data`] = undefined;
          state[`${item}Error`] = undefined;
          state[`${item}Array`] = undefined;
        });
        return { ...state };
      }
      return {};
    default:
      return state;
  }
}
