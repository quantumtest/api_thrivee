#!/bin/bash
cd /home/telemed_fe && npm run stop-prod
cd /home/telemed_fe && npm run build
cd /home/telemed_fe && npm run start-prod
