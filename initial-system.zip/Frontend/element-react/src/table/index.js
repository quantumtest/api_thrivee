import Table from './TableStore';
import TableColumn from './TableColumn';

Table.Column = TableColumn;

export default Table;