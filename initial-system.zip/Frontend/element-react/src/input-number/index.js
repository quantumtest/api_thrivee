import InputNumber from './InputNumber';

export default InputNumber;
