import Tabs from './Tabs'
import TabPane from './TabPane'

Tabs.Pane = TabPane;

export default Tabs;
