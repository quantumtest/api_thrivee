import Collapse from './Collapse';
import CollapseItem from './CollapseItem';

Collapse.Item = CollapseItem;

export default Collapse;
